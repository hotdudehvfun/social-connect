<?php

require 'connect.php';
$echoArray=array();

$message=$_POST['message'];
$author=$_POST['author'];
$groupid=$_POST['groupId'];

//insert new row
$sql = "INSERT INTO groupmessages (message,isremoved,author,groupid,time) VALUES('$message','n','$author','$groupid',NOW())";
$result = mysqli_query($conn, $sql);
if ($result)
{
	$echoArray['success']=true;
}else
{
	$echoArray['success']=false;
}
mysqli_close($conn);
echo json_encode($echoArray);
?>