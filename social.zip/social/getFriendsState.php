<?php
require 'connect.php';

$username=$_POST['username'];
$target=$_POST['target'];

$echoArray=array();
$sql="select areFriends from friends where user1='$username' and user2='$target'";
$result = mysqli_query($conn, $sql);
$rowCount=mysqli_num_rows($result);
$echoArray['rowCount']=$rowCount;
$echoArray['sql']=$sql;
if ($rowCount>0)
{
        // fetch rows
        $row=mysqli_fetch_row($result);
        mysqli_free_result($result);
        $echoArray['areFriends']=$row['0'];
        $echoArray['success']=true;
        $echoArray['rowCount']=$rowCount;
}else
{
    $echoArray['areFriends']='v';
    $echoArray['success']=true;
    $echoArray['rowCount']=$rowCount;
}
mysqli_close($conn);
echo json_encode($echoArray);
?>
