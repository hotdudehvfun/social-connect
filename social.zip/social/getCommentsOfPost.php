<?php
require 'connect.php';


$postId=(int)$_POST['postId'];

$echoArray=array();
//INSERT INTO `comments`(`author`, `postId`, `text`, `isRemoved`, `time`)  VALUES ('harry_potter',68,'welcome to social connect','n',NOW())
$sql="SELECT comments.*,users.name,users.photo FROM comments INNER JOIN users ON comments.author=users.username WHERE postId=$postId";
$result = mysqli_query($conn, $sql);
$rowCount=mysqli_num_rows($result);
$echoArray['rowCount']=$rowCount;
if ($rowCount>0)
{
        // Fetch one and one row
        $list=array();
        while ($row=mysqli_fetch_row($result))
        {
            //id0 author1 postId2 text3 isRemoved4 time5 name6 photo7
            array_push($list, $row);
        }
        mysqli_free_result($result);
        $echoArray['list']=$list;
        $echoArray['message']="";
        $echoArray['success']=true;
        $echoArray['rowCount']=$rowCount;
}else
{
    $echoArray['message']="There are no posts to display...";
    $echoArray['success']=false;
    $echoArray['rowCount']=$rowCount;
}
mysqli_close($conn);
echo json_encode($echoArray);
?>
