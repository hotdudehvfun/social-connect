<?php
require 'connect.php';

$echoArray=array();
$username = mysqli_real_escape_string($conn,$_POST['username']);

$sql = "SELECT username,name,photo FROM users WHERE username = '$username'";
$result = mysqli_query($conn, $sql);
$rowCount=mysqli_num_rows($result);
$echoArray['sql']=$sql;
if ($rowCount==1)
{
	$row=mysqli_fetch_row($result);
	$echoArray['username']=$row[0];
	$echoArray['name']=$row[1];
	$echoArray['photo']=$row[2];
	$echoArray['success']=true;
}else
{
	$echoArray['success']=false;
}
mysqli_close($conn);
echo json_encode($echoArray);
?>