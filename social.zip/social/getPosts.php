<?php
require 'connect.php';


$username=$_POST['username'];

$echoArray=array();
//show posts from friends and self
$sql="SELECT posts.*,users.name,users.photo from posts INNER JOIN users ON users.username=posts.username WHERE (posts.username in (SELECT users.username FROM users WHERE users.username in (select friends.user2 from friends where friends.areFriends='y' and friends.user1='$username')) OR posts.username='$username') and posts.isremoved='n' ORDER by time DESC";
$result = mysqli_query($conn, $sql);
$rowCount=mysqli_num_rows($result);
$echoArray['rowCount']=$rowCount;
if ($rowCount>0)
{

        // Fetch one and one row
        $posts=array();
        while ($row=mysqli_fetch_row($result))
        {
            //id0 type1 text2 image3 time4 username5 isremoved6 name7 photo8
            array_push($posts, $row);
        }
        mysqli_free_result($result);
        $echoArray['posts']=$posts;
        $echoArray['message']="";
        $echoArray['success']=true;
        $echoArray['rowCount']=$rowCount;
}else
{
    $echoArray['message']="There are no posts to display...";
    $echoArray['success']=false;
    $echoArray['rowCount']=$rowCount;
}
mysqli_close($conn);
echo json_encode($echoArray);
?>
