<?php

require 'connect.php';

$echoArray=array();
$id=(int)$_POST['post_id'];
//insert new row
$sql = "UPDATE posts SET isremoved='y' WHERE id=".$id;
mysqli_query($conn, $sql);
$count=mysqli_affected_rows($conn);
	if ($count>0)
	{
		$echoArray['success']=true;
	}else
	{
		$echoArray['success']=false;
	}
$echoArray['sql']=$sql;
mysqli_close($conn);
echo json_encode($echoArray);
?>