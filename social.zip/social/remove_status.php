<?php

require 'connect.php';

$echoArray=array();
$id=(int)$_POST['post_id'];
//insert new row
$sql = "UPDATE posts SET isremoved='y' WHERE id=$id";
if (mysqli_query($conn, $sql))
{
	$echoArray['success']=true;
}else
{
	$echoArray['success']=false;
}
$echoArray['sql']=$sql;
mysqli_close($conn);
echo json_encode($echoArray);
?>