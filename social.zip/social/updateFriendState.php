<?php
require 'connect.php';

$username=$_POST['username'];
$target=$_POST['target'];
$oldState=$_POST['oldState'];
$newState=$_POST['newState'];


$echoArray=array();

if ($oldState=='v')
{
	//insert new row
	$sql="insert into friends (user1,user2,areFriends) values( '$username', '$target', '$newState')";
	$result = mysqli_query($conn, $sql);

	$sql="insert into friends (user1,user2,areFriends) values( '$target', '$username', '$newState')";
	$result = mysqli_query($conn, $sql);
	if ($result)
	{
		$echoArray['success']=true;
		$echoArray['message']="Friend state changed";
	}else{
		$echoArray['success']=false;
		$echoArray['message']="Failed to change state of friend";
	}
}else
{
	//update state
	$sql="update friends set areFriends='$newState' where user1='$username' and user2='$target'";
	$result = mysqli_query($conn, $sql);
	$echoArray['s1']=$sql;


	$sql="update friends set areFriends='$newState' where user1='$target' and user2='$username'";
	$result = mysqli_query($conn, $sql);
	$echoArray['s2']=$sql;

	if ($result)
	{
		$echoArray['success']=true;
		$echoArray['message']="Friend state changed";
	}else{
		$echoArray['success']=false;
		$echoArray['message']="Failed to change state of friend";
	}
}
mysqli_close($conn);
echo json_encode($echoArray);
?>
