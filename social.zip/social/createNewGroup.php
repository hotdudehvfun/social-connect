<?php
require 'connect.php';

$echoArray=array();
$admin = mysqli_real_escape_string($conn,$_POST['admin']);
$groupName =mysqli_real_escape_string($conn,$_POST['groupName']);


$sql = "INSERT INTO groups (admin,groupname,groupState,photo,time) values('$admin','$groupName',1,'app_resources/app_images/group_icon.jpg',NOW())";
$echoArray['$sql1']=$sql;
if (mysqli_query($conn,$sql))
{
	$echoArray['isCreated']=true;
	$echoArray['createMessage']="Group created successfully!";
	$groupId=mysqli_insert_id($conn);


	$sql="INSERT INTO groupmembers (groupid,username,rights) VALUES ($groupId,'$admin',1)";
	$echoArray['$sql2']=$sql;
	if (mysqli_query($conn,$sql))
	{
		$echoArray['isAdmin']=true;
		$echoArray['adminMessage']="You are now admin of created group";
	}else{
		$echoArray['isAdmin']=false;
		$echoArray['adminMessage']="Group created but failed to make you admin of this group! Error:".mysqli_error($conn);
	}

}else
{
		$echoArray['isCreated']=false;
		$echoArray['createMessage']="Failed to create new group record :Error".mysqli_error($conn);
}
mysqli_close($conn);
echo json_encode($echoArray);
?>