<?php
require 'connect.php';

$username=$_POST['username'];
$echoArray=array();

$sql="SELECT users.username,users.name,users.photo from users where users.username in (SELECT DISTINCT recipient FROM messages as a WHERE (a.author = '$username') and a.isremoved='n' ORDER BY time ASC)";
$echoArray['listSent']=getRecentChatUsers($conn,$username,$sql);

$sql="SELECT users.username,users.name,users.photo from users where users.username in (SELECT DISTINCT author FROM messages as a WHERE (a.recipient = '$username') and a.isremoved='n' ORDER BY time ASC)";
$echoArray['listReceived']=getRecentChatUsers($conn,$username,$sql);
mysqli_close($conn);
echo json_encode($echoArray);
function getRecentChatUsers($conn,$user,$sql)
{
    $result = mysqli_query($conn, $sql);
    $friendList=array();
    while($r = mysqli_fetch_assoc($result))
    {
        array_push($friendList, $r);
    }
    mysqli_free_result($result);
    return $friendList;
}
?>
