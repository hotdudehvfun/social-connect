<?php
require 'connect.php';

$query=mysqli_real_escape_string($conn,$_POST['query']);

$echoArray=array();
//show all posts
$sql="SELECT username,name,photo FROM users WHERE name REGEXP '$query' or username REGEXP '$query'";
$result = mysqli_query($conn, $sql);
$rowCount=mysqli_num_rows($result);
$echoArray['rowCount']=$rowCount;
if ($rowCount>0)
{

        // Fetch one and one row
        $list=array();
        while ($row=mysqli_fetch_row($result))
        {
            //id type text image time username
            array_push($list, $row);
        }
        mysqli_free_result($result);
        $echoArray['list']=$list;
        $echoArray['message']="Search results...";
        $echoArray['success']=true;
        $echoArray['rowCount']=$rowCount;
}else
{
    $echoArray['message']="Your query returned 0 search results";
    $echoArray['success']=true;
    $echoArray['rowCount']=$rowCount;
}
mysqli_close($conn);
echo json_encode($echoArray);
?>
