<?php
require 'connect.php';

//INSERT into groups (admin,groupname,photo,time) values ('harry_potter','Hogwarts','none',NOW());
$username=$_POST['username'];

$echoArray=array();
$sql="SELECT * FROM groupmembers INNER JOIN groups on groups.groupid=groupmembers.groupid WHERE groupmembers.username='$username' and groups.groupState=1";
$result = mysqli_query($conn, $sql);
$rowCount=mysqli_num_rows($result);
$echoArray['rowCount']=$rowCount;
$echoArray['sql']=$sql;
if ($rowCount>0)
{
        // fetch rows
        $list=array();
        while ($row=mysqli_fetch_row($result))
        {
            array_push($list, $row);
        }
        mysqli_free_result($result);
        $echoArray['list']=$list;
        $echoArray['success']=true;
        $echoArray['rowCount']=$rowCount;
}else
{
    $echoArray['message']="You have no active groups!!!";
    $echoArray['success']=true;
    $echoArray['rowCount']=$rowCount;
}
mysqli_close($conn);
echo json_encode($echoArray);
?>
