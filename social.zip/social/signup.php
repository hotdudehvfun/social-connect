<?php
require 'connect.php';

$echoArray=array();
$username = mysqli_real_escape_string($conn,$_POST['username']);
$password = mysqli_real_escape_string($conn,$_POST['password']);


$sql = "SELECT username FROM users WHERE username = '$username'";
$result = mysqli_query($conn, $sql);
$rowCount=mysqli_num_rows($result);

if ($rowCount==1)
{
	$echoArray['success']=false;
	$echoArray['message']="Username not available. Choose different username!!!";
}else
{
	//username available
	$sql="INSERT into users (username,password,name,photo) VALUES ('$username','$password','$username','none')";
	if (mysqli_query($conn,$sql))
	{
		$echoArray['username']=$username;
		$echoArray['name']=$username;
		$echoArray['success']=true;
		$echoArray['message']="You have successfully signed up.";
	}else{
		$echoArray['success']=false;
		$echoArray['message']="Failed to insert record into server:Error".mysqli_error($conn);
	}
}
mysqli_close($conn);
echo json_encode($echoArray);
?>