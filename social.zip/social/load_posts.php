<?php
require 'connect.php';

$echoArray=array();
//show all posts
$sql="select * from posts inner join users on posts.username=users.username where posts.isremoved='n' order by time desc ";
$result = mysqli_query($conn, $sql);
$rowCount=mysqli_num_rows($result);
$echoArray['rowCount']=$rowCount;
if ($rowCount>0)
{

        // Fetch one and one row
        $posts=array();
        while ($row=mysqli_fetch_row($result))
        {
            //id type text image time username
            array_push($posts, $row);
        }
        mysqli_free_result($result);
        $echoArray['posts']=$posts;
        $echoArray['message']="Loading posts...";
        $echoArray['success']=true;
        $echoArray['rowCount']=$rowCount;
}else
{
    $echoArray['message']="There are no posts to display...";
    $echoArray['success']=true;
    $echoArray['rowCount']=$rowCount;
}
mysqli_close($conn);
echo json_encode($echoArray);
?>
