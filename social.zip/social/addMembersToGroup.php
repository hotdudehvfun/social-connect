<?php
require 'connect.php';

$echoArray=array();
$jsonList=json_decode($_POST['jsonList']);
$groupid=$_POST['groupid'];


$sql = "INSERT INTO groupmembers (groupid,username,rights) values ";
for ($i=0; $i < count($jsonList); $i++)
{
	$sql.="($groupid,'$jsonList[$i]',2),";
}

$sql=substr($sql,0,strlen($sql)-1);
$echoArray['sql']=$sql;
if (mysqli_query($conn,$sql))
{
	$echoArray['success']=true;
	$echoArray['message']=count($jsonList)." persons added successfully!";
}else
{
	$echoArray['success']=false;
	$echoArray['message']="Failed to add persons to group!!!".mysqli_error();
}
mysqli_close($conn);
echo json_encode($echoArray);

?>