<?php

require 'connect.php';
$echoArray=array();

$type=$_POST['type'];
$text=$_POST['text'];
$image=$_POST['image'];
$time=$_POST['time'];
$isremoved=$_POST['isremoved'];
$username=$_POST['username'];

//insert new row
$sql = "INSERT INTO posts (type, text,image,time,username,isremoved) VALUES "."( '".$type."',".  "'".$text."',".  "'".$image."'," . "'".$time."',"."'".$username."',"."'".$isremoved."')";
	$result = mysqli_query($conn, $sql);
			if ($result)
			{
				$echoArray['message']="Status posted successfully!!!";
				$echoArray['success']=true;
			}else
			{
				$echoArray['message']="Status could not be posted due to internal server error!!!";
				$echoArray['success']=false;
			}
$echoArray['sql']=$sql;
mysqli_close($conn);
echo json_encode($echoArray);
?>