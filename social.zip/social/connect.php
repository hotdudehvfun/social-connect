<?php
error_reporting(E_ERROR | E_PARSE);
// error_reporting(E_ALL);
// ini_set('display_errors', '1');

$servername = "localhost";
$username = "root";
$password = "1234";
$db = "social";

// Create connection
 $conn = mysqli_connect($servername, $username, $password,$db);

// Check connection
if (!$conn)
{
    die("Connection failed: " . $conn->connect_error);
}
?>
