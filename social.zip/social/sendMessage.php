<?php

require 'connect.php';
$echoArray=array();

$message=$_POST['message'];
$author=$_POST['author'];
$recipient=$_POST['recipient'];
$time=$_POST['time'];

//insert new row
$sql = "INSERT INTO messages (message,author,recipient,time) VALUES('$message','$author','$recipient','$time')";
$result = mysqli_query($conn, $sql);
if ($result)
{
	$echoArray['success']=true;
}else
{
	$echoArray['success']=false;
}
mysqli_close($conn);
echo json_encode($echoArray);
?>