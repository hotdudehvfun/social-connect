<?php
require 'connect.php';


$groupid=(int)$_POST['groupid'];

$echoArray=array();
//show all posts
$sql="SELECT  a.*,users.name,users.photo FROM users,groupmessages as a WHERE (a.groupid = $groupid and a.isremoved='n' and users.username=a.author) ORDER   BY time ASC";
$result = mysqli_query($conn, $sql);
$rowCount=mysqli_num_rows($result);
$echoArray['sql']=$sql;
if ($rowCount>0)
{
        // Fetch one and one row
        $groupMessages=array();
        while ($row=mysqli_fetch_row($result))
        {
            array_push($groupMessages,$row);
        }
        mysqli_free_result($result);
        $echoArray['groupMessages']=$groupMessages;
        $echoArray['success']=true;
        $echoArray['rowCount']=$rowCount;
}else
{
    $echoArray['message']="No conversation here....";
    $echoArray['success']=false;
    $echoArray['rowCount']=$rowCount;
}
mysqli_close($conn);
echo json_encode($echoArray);
?>
