<?php
require 'connect.php';

$username=$_POST['username'];
$echoArray=array();

$echoArray['friendList']=getFriendList($conn,$username);
$echoArray['friendList_o']=getPendingList($conn,$username,'o');
$echoArray['friendList_i']=getPendingList($conn,$username,'i');
mysqli_close($conn);
echo json_encode($echoArray);
function getFriendList($conn,$user)
{
    $sql="SELECT users.username,users.name,users.photo FROM users WHERE users.username in (select friends.user2 from friends where friends.areFriends='y' and friends.user1='$user')";
    $result = mysqli_query($conn, $sql);
    $friendList=array();
    while($r = mysqli_fetch_assoc($result))
    {
        array_push($friendList, $r);
    }
    mysqli_free_result($result);
    return $friendList;
}

function getPendingList($conn,$user,$origin)
{
    $sql="SELECT users.username,users.name,users.photo FROM users WHERE users.username in (select friends.user2 from friends where friends.areFriends='p' and friends.user1='$user' and friends.requestOrigin='$origin')";
    $result = mysqli_query($conn, $sql);
    $rowCount=mysqli_num_rows($result);
    $friendList=array();
    while($r = mysqli_fetch_assoc($result))
    {
        array_push($friendList, $r);
    }
    mysqli_free_result($result);
    // echo json_encode($friendList);
    return $friendList;
}

?>
