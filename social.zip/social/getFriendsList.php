<?php
require 'connect.php';

$username=$_POST['username'];

$echoArray=array();
$sql="select users.username,users.name,users.photo from users where (users.username=(SELECT user2 FROM friends WHERE user1 = '$username' AND areFriends='y'))";
$result = mysqli_query($conn, $sql);
$rowCount=mysqli_num_rows($result);
$echoArray['rowCount']=$rowCount;
$echoArray['sql']=$sql;
if ($rowCount>0)
{
        // fetch rows
        $friendList=array();
        while ($row=mysqli_fetch_row($result))
        {
            array_push($friendList, $row);
        }
        mysqli_free_result($result);
        $echoArray['friendList']=$friendList;
        $echoArray['success']=true;
        $echoArray['rowCount']=$rowCount;
}else
{
    $echoArray['message']="You have no friends";
    $echoArray['success']=true;
    $echoArray['rowCount']=$rowCount;
}
mysqli_close($conn);
echo json_encode($echoArray);
?>
