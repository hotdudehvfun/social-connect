<?php
require 'pdo_connect.php';
$echoArray=array();
try
{
    $conn=new Connection();
    $pdo=$conn->open();
    if ($pdo)
    {
        //get comment count
        $postIdList=explode("#",$_POST["postIdList"]);
        for ($i=0; $i < count($postIdList); $i++)
        {
            $stmt = $pdo->prepare("select postId,count(text) as c from comments where postId=?");
            $stmt->execute([ (int)$postIdList[$i]]);
            $arr = $stmt->fetchAll(PDO::FETCH_ASSOC);//returns 2d array
            $echoArray[$postIdList[$i]]=$arr[0]["c"];
        }
        $echoArray["success"]=true;
        $stmt = null;
    }else
    {
        $echoArray["success"]=false;
    }
    $conn->close();
}catch(PDOException $e)
{
    echo "Exception:".$e->getMessage();
}
echo json_encode($echoArray);
?>