<?php
require 'connect.php';

$username=$_POST['author'];
$recipient=$_POST['recipient'];

$echoArray=array();
//show all posts
$sql="SELECT  * FROM    messages as a WHERE   (a.author = '$username' AND a.recipient = '$recipient') OR (a.author = '$recipient' AND a.recipient = '$username') and a.isremoved='n' ORDER   BY time ASC";
$result = mysqli_query($conn, $sql);
$rowCount=mysqli_num_rows($result);
$echoArray['sql']=$sql;
if ($rowCount>0)
{

        // Fetch one and one row
        $sentMessages=array();
        while ($row=mysqli_fetch_row($result))
        {
            array_push($sentMessages,$row);
        }
        mysqli_free_result($result);
        $echoArray['sentMessages']=$sentMessages;
        $echoArray['success']=true;
        $echoArray['rowCount']=$rowCount;
}else
{
    $echoArray['message']="No conversation here....";
    $echoArray['success']=false;
    $echoArray['rowCount']=$rowCount;
}
mysqli_close($conn);
echo json_encode($echoArray);
?>
