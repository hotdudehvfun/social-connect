<?php

require 'connect.php';
$echoArray=array();

$author=$_POST['author'];
$postId=(int)$_POST['postId'];
$text=$_POST['text'];

//insert new row
$sql = "INSERT INTO comments (author,postId,text,isRemoved,time) values('$author',$postId,'$text','n',NOW())";
$result = mysqli_query($conn, $sql);
if ($result)
{
	$echoArray['success']=true;
	$echoArray['message']="Comment added!";
}else
{
	$echoArray['success']=false;
	$echoArray['message']="Failed to add comment! Error:".mysqli_error();
}
$echoArray['sql']=$sql;
mysqli_close($conn);
echo json_encode($echoArray);
?>