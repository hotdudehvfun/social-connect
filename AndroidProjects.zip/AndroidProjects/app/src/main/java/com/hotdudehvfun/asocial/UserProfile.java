package com.hotdudehvfun.asocial;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;
import com.android.volley.Request.Method;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.NetworkImageView;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONObject;

public class UserProfile extends AppCompatActivity {


  NetworkImageView coverPhoto,userProfilePhoto;
  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_user_profile);

    bindEvents();
    loadUserProfileData();
  }


  public void bindEvents()
  {
    userProfilePhoto=findViewById(R.id.user_profile_photo);
    coverPhoto=findViewById(R.id.user_cover_photo);

    findViewById(R.id.new_post).setOnClickListener(new OnClickListener() {
      @Override
      public void onClick(View v) {
        //open dialog to post something
      }
    });
  }

  public void loadPhoto(String url,NetworkImageView imageView)
  {
    ImageLoader imageLoader=VolleyImageLoad.getInstance(this.getApplicationContext()).getImageLoader();
    imageLoader.get(url, ImageLoader.getImageListener(imageView,
        R.drawable.ic_person_black_24dp, android.R.drawable.stat_notify_error));
    imageView.setImageUrl(url,imageLoader);
  }

  public void loadUserProfileData()
  {
    try {
      StringRequest putRequest = new StringRequest(Method.POST, Utility.siteUrl+"/getUserProfile.php",
          new Response.Listener<String>()
          {
            @Override
            public void onResponse(String response) {
              // response
              try {
                JSONObject obj=new JSONObject(response);
                if (obj.getBoolean("success"))
                {

                  //fill data into views
                  ((TextView)findViewById(R.id.user_full_name)).setText(obj.getString("name"));
                  loadPhoto(Utility.siteUrl+obj.getString("photo"),userProfilePhoto);
                  loadPhoto("https://www.bing.com/az/hprichbg/rb/KilchurnSky_EN-IN9115024751_1920x1080.jpg",coverPhoto);

                }else {

                }
              } catch (Exception e)
              {
                e.printStackTrace();
              }
            }
          },
          new Response.ErrorListener()
          {
            @Override
            public void onErrorResponse(VolleyError error)
            {

            }
          }
      ) {

        @Override
        protected Map<String, String> getParams()
        {
          Map<String, String>  params = new HashMap<String, String>();
          params.put("username", TinyDB.getInstance().getString("username"));
          return params;
        }

      };

      RequestQueue requestQueue= Volley.newRequestQueue(this);
      requestQueue.add(putRequest);
      requestQueue.start();
    } catch (Exception e)
    {
      e.printStackTrace();
    }
  }
}
