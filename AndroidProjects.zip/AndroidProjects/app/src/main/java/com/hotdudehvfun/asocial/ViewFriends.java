package com.hotdudehvfun.asocial;

import android.content.Intent;
import android.graphics.Color;
import android.support.design.widget.Snackbar;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.Request.Method;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.NetworkImageView;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ViewFriends extends AppCompatActivity {

  TextView log;
  LinearLayout tabContainer;
  JSONArray[] friendsArray;//0=friend list 1=incoming 2=sent
  int selectedTab;
  @Override
  protected void onCreate(Bundle savedInstanceState)
  {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_view_friends);
    log=findViewById(R.id.log);

    setUpTabLayout();
    getFriendList();
  }

  public void setUpTabLayout()
  {
    tabContainer=findViewById(R.id.tab_container);
    for (int i = 0; i <=2 ; i++)
    {
      tabContainer.getChildAt(i).setTag(i);
      tabContainer.getChildAt(i).setOnClickListener(new OnClickListener() {
        @Override
        public void onClick(View v)
        {
          selectedTab= (int) v.getTag();
          selectTab((Integer) v.getTag());
        }
      });
    }

  }
  public void setTabState(int color,int index)
  {
    ((TextView)((LinearLayout)tabContainer.getChildAt(index)).getChildAt(0)).setTextColor(color);
    (((LinearLayout)tabContainer.getChildAt(index)).getChildAt(1)).setBackgroundColor(color);
  }
  public void selectTab(int num)
  {

    tabContainer=findViewById(R.id.tab_container);
    int nonActiveColor=Color.parseColor("#a6a6a6");
    int activeColor= ContextCompat.getColor(ViewFriends.this,R.color.colorPrimaryDark);

    //clear all tabs
    setTabState(nonActiveColor,0);
    setTabState(nonActiveColor,1);
    setTabState(nonActiveColor,2);

    //now make tab active
    setTabState(activeColor,num);
    createFriendListLayout(friendsArray[num],num);
  }

  public void getFriendList()
  {
    try
    {
      log.setText("Please wait! Loading your friends....");
      StringRequest putRequest = new StringRequest(Method.POST, Utility.siteUrl+"/getFriendsList.php",
          new Response.Listener<String>()
          {
            @Override
            public void onResponse(String response) {
              // response
              try
              {
                Log.d("#info",response);
                JSONObject obj=new JSONObject(response);

                friendsArray=new JSONArray[3];
                friendsArray[0]=obj.getJSONArray("friendList");
                friendsArray[1]=obj.getJSONArray("friendList_i");
                friendsArray[2]=obj.getJSONArray("friendList_o");
                selectTab(0);


              } catch (Exception e)
              {
                e.printStackTrace();
                Snackbar.make(findViewById(R.id.parent),"Exception occurred while fetching data Exception"+e.getMessage(),Snackbar.LENGTH_LONG).show();
              }
            }
          },
          new Response.ErrorListener()
          {
            @Override
            public void onErrorResponse(VolleyError error)
            {
              Toast.makeText(ViewFriends.this,"Error while getting friend list: Error is:"+error.getMessage(),Toast.LENGTH_LONG);
            }
          }
      ) {

        @Override
        protected Map<String, String> getParams()
        {
          Map<String, String>  params = new HashMap<>();
          params.put("username",TinyDB.getInstance().getString("username"));
          return params;
        }

      };

      RequestQueue requestQueue= Volley.newRequestQueue(this);
      requestQueue.add(putRequest);
      requestQueue.start();

    }catch (Exception e)
    {
      e.printStackTrace();

    }
  }

  public void createFriendListLayout(JSONArray postArray,int type)
  {
    try {
      LinearLayout feed_container=findViewById(R.id.friends_container);
      feed_container.removeAllViews();
      if (postArray.length()==0)
      {
        log.setText("Its all empty here!!!");
      }else
        {

        for (int i = 0; i <postArray.length() ; i++)
        {
          JSONObject row=postArray.getJSONObject(i);
          //username0 name1 photo2
          LinearLayout child= (LinearLayout) getLayoutInflater().inflate(R.layout.one_friend_layout,null);


          ((TextView)child.findViewById(R.id.friendName)).setText(row.getString("name"));
          Utility.getImage(getApplicationContext(),Utility.siteUrl+row.getString("photo"),(NetworkImageView) child.findViewById(R.id.friendProfileIcon));

          //handle click on friend
          child.findViewById(R.id.parent).setTag(row.toString());
          child.findViewById(R.id.parent).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
              Intent intent=new Intent(ViewFriends.this,PersonProfile.class);
              try {
                JSONObject temp=new JSONObject(view.getTag().toString());
                intent.putExtra("person-username",temp.getString("username"));
                intent.putExtra("person-name",temp.getString("name"));
                intent.putExtra("person-photo",temp.getString("photo"));
                startActivity(intent);
              } catch (JSONException e) {
                e.printStackTrace();
              }
            }
          });

          //handle accept and cancel request on sent and received
          //incoming
          //can be cancelled or accepted

          //hide accept button
          //show only if incoming requests
          LinearLayout actionContainer=child.findViewById(R.id.friend_request_action_container);
          actionContainer.setVisibility(View.VISIBLE);
          actionContainer.findViewById(R.id.accept_action).setTag(row.getString("username"));
          actionContainer.findViewById(R.id.accept_action).setOnClickListener(
              new OnClickListener() {
                @Override
                public void onClick(View v)
                {
                  //accept friend request
                  setFriendState("y",v.getTag().toString());

                }
              });

          actionContainer.findViewById(R.id.cancel_action).setTag(row.getString("username"));
          actionContainer.findViewById(R.id.cancel_action).setOnClickListener(
              new OnClickListener() {
                @Override
                public void onClick(View v)
                {
                  //reject friend request
                  setFriendState("n",v.getTag().toString());
                }
              });

          if (type==0)
          {
            actionContainer.setVisibility(View.GONE);
            log.setText("Connected with "+postArray.length()+" friends :)");
          }else if(type==1)
          {
            actionContainer.setVisibility(View.VISIBLE);
            actionContainer.findViewById(R.id.accept_action).setVisibility(View.VISIBLE);
            log.setText(postArray.length()+" pending requests");
          }else {
            actionContainer.setVisibility(View.VISIBLE);
            actionContainer.findViewById(R.id.accept_action).setVisibility(View.GONE);
            log.setText(postArray.length()+" pending requests");

          }


          feed_container.addView(child);
        }

      }

    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public void setFriendState(final String newState,final String target)
  {
    try {
      StringRequest putRequest = new StringRequest(Method.POST, Utility.siteUrl+"/updateFriendState.php",
          new Response.Listener<String>()
          {
            @Override
            public void onResponse(String response)
            {
              // response
              try {
                JSONObject obj=new JSONObject(response);
                Log.d("#info",response);
                if (obj.getBoolean("success"))
                {
                  //load new state
                  String msg="";
                  if (newState=="y")
                  msg="Hurray! You both are now friends:)";
                  if (newState=="n")
                    msg="You cancelled the friend request!!!";
                  Snackbar.make(findViewById(R.id.parent),msg,Snackbar.LENGTH_LONG).show();

                }else {
                  Snackbar.make(findViewById(R.id.parent),"Error while updating friend state"+obj.getString("message"),Snackbar.LENGTH_LONG).show();
                }
                getFriendList();
                selectTab(selectedTab);
              } catch (Exception e)
              {
                e.printStackTrace();
              }
            }
          },
          new Response.ErrorListener()
          {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
          }
      ) {

        @Override
        protected Map<String, String> getParams()
        {
          Map<String, String>  params = new HashMap<String, String>();
          params.put("username",TinyDB.getInstance().getString("username"));
          params.put("target",target);
          params.put("newState",newState);
          params.put("oldState","p");
          return params;
        }

      };

      RequestQueue requestQueue= Volley.newRequestQueue(this);
      requestQueue.add(putRequest);
      requestQueue.start();
    } catch (Exception e)
    {
      e.printStackTrace();
    }
  }

}
