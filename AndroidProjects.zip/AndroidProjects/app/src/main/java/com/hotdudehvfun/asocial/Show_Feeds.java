package com.hotdudehvfun.asocial;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.Request.Method;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.NetworkImageView;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


class Status
{
  public String text,type,image,time;
  public static String TEXT="text",IMAGE="img";
  boolean hasImage;
  Status()
  {
    this.type=Status.TEXT;
    this.text="";
    this.image="none";
    this.time="";
    this.hasImage=false;
  }
}

public class Show_Feeds extends AppCompatActivity {

  TextView log;
  Status newStatus;
  LinearLayout drawer;
  boolean isDrawerOpen=false;
  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.show_feeds_with_drawer);
    log=findViewById(R.id.log);

    getFeedsFromServer();
    setUpPostStatus();
    setUpNavDrawer();
    checkWhoIsLoggedIn();
  }

  public void checkWhoIsLoggedIn()
  {
    //set name of user
    Toast.makeText(Show_Feeds.this,"Welcome "+TinyDB.getInstance().getString("name"),Toast.LENGTH_LONG).show();
    ((TextView)drawer.findViewById(R.id.user_name)).setText(TinyDB.getInstance().getString("name"));

    //set profile picture in drawer
    String photoUrl=TinyDB.getInstance().getString("photo");
    NetworkImageView imageView=drawer.findViewById(R.id.profile_pic_in_drawer);
    loadImageFromURL(photoUrl,imageView);
  }
  public void loadImageFromURL(String url,NetworkImageView imageView)
  {
    ImageLoader imageLoader=VolleyImageLoad.getInstance(this.getApplicationContext()).getImageLoader();
    imageLoader.get(Utility.siteUrl+url, ImageLoader.getImageListener(imageView,
        R.drawable.ic_person_black_24dp, android.R.drawable
            .ic_dialog_alert));
    imageView.setImageUrl(url,imageLoader);
  }

  public void loadPostsFromJson(JSONArray postArray)
  {
    try {
      LinearLayout feed_container=findViewById(R.id.post_container);
      feed_container.removeAllViews();
      for (int i = 0; i <postArray.length() ; i++)
      {
        //create layouts
        JSONArray row=postArray.getJSONArray(i);
//id0 type1 text2 image3 time4 username5 isremove6 username7 password8 name9 photo10
//["1","text","hahhaha","null","2018-09-10 00:00:00","user1","user1","1234","user","null"]
        if (row.getString(1).compareToIgnoreCase("text")==0)
        {
          //prepare text status
          LinearLayout child= (LinearLayout) getLayoutInflater().inflate(R.layout.fragment_post_with_text,null);
          LinearLayout.LayoutParams lp= new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
          lp.setMargins(0,20,0,20);
          child.setLayoutParams(lp);
          ((TextView)child.findViewById(R.id.name)).setText(row.getString(9));
          ((TextView)child.findViewById(R.id.date)).setText(row.getString(4));
          ((TextView)child.findViewById(R.id.text)).setText(row.getString(2));
          child.setTag(row.getString(5));

          //handle more options
          child.findViewById(R.id.more_options).setTag(row.getInt(0));
          child.findViewById(R.id.more_options).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
              handleMoreOptionsOnPost(view);
            }
          });

          feed_container.addView(child);
        }else
        {
          //prepare image status
        }
      }
    } catch (JSONException e) {
      e.printStackTrace();
    }
  }
  public void handleMoreOptionsOnPost(final View view)
  {
    PopupMenu postMoreOptions=new PopupMenu(Show_Feeds.this,view);
    postMoreOptions.getMenuInflater().inflate(R.menu.post_more_options,postMoreOptions.getMenu());
    postMoreOptions.show();
    postMoreOptions.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
      @Override
      public boolean onMenuItemClick(MenuItem menuItem)
      {
        if (menuItem.getItemId()==R.id.remove_post)
        {
          //remove this post
          removePost((int)view.getTag());

        }
        return false;
      }
    });
  }
  public void getFeedsFromServer()
  {
    try {
      log.setText("Loading posts....");

      StringRequest putRequest = new StringRequest(Method.POST, Utility.siteUrl+"/load_posts.php",
          new Response.Listener<String>()
          {
            @Override
            public void onResponse(String response)
            {
              // response
              try {
                JSONObject obj=new JSONObject(response);
                if (obj.getBoolean("success"))
                {
                  log.setText(obj.getString("message"));
                  findViewById(R.id.loading_feed_progress).setVisibility(View.GONE);
                  if (obj.getInt("rowCount")==0)
                  {
                    ((LinearLayout)findViewById(R.id.post_container)).removeAllViews();

                  }else{
                    log .setText("Recent feeds :)");
                    loadPostsFromJson(obj.getJSONArray("posts"));
                  }
                }else {
                  log.setText(obj.getString("message"));
                }
              } catch (Exception e)
              {
                e.printStackTrace();
                log.setText("Exception occured while loading posts Exception:"+e.getMessage());
              }
            }
          },
          new Response.ErrorListener()
          {
            @Override
            public void onErrorResponse(VolleyError error) {
              log.setText("Error response:"+error.getMessage());
            }
          }
      ) {

        @Override
        protected Map<String, String> getParams()
        {
          Map<String, String>  params = new HashMap<String, String>();
          return params;
        }

      };

      RequestQueue requestQueue= Volley.newRequestQueue(this);
      requestQueue.add(putRequest);
      requestQueue.start();
    } catch (Exception e)
    {
      e.printStackTrace();
    }
  }

  public void removePost(final int id)
  {
    try {
      log.setText("Loading posts....");

      StringRequest putRequest = new StringRequest(Method.POST, Utility.siteUrl+"/remove_status.php",
          new Response.Listener<String>()
          {
            @Override
            public void onResponse(String response) {
              // response
              try {
                JSONObject obj=new JSONObject(response);
                if (obj.getBoolean("success"))
                {
                  Toast.makeText(getApplicationContext(),"Refreshing posts...",Toast.LENGTH_LONG);
                  getFeedsFromServer();
                }else{
                  Toast.makeText(getApplicationContext(),"Failed to remove post...",Toast.LENGTH_LONG);
                }
              } catch (Exception e)
              {
                e.printStackTrace();
                log.setText("Exception occured while remoing post Exception:"+e.getMessage());
              }
            }
          },
          new Response.ErrorListener()
          {
            @Override
            public void onErrorResponse(VolleyError error) {
              log.setText("Error response:"+error.getMessage());
            }
          }
      ) {

        @Override
        protected Map<String, String> getParams()
        {
          Map<String, String>  params = new HashMap<String, String>();
          params.put("post_id",id+"");
          return params;
        }

      };

      RequestQueue requestQueue= Volley.newRequestQueue(this);
      requestQueue.add(putRequest);
      requestQueue.start();
    } catch (Exception e)
    {
      e.printStackTrace();
    }
  }

  public void resetPostStatus()
  {
    //hide cancel button
    findViewById(R.id.post_status_buttons).findViewById(R.id.cancel_action).setVisibility(View.GONE);
    //hide remove photo
    findViewById(R.id.post_status_buttons).findViewById(R.id.remove_image_action).setVisibility(View.GONE);
    //hide image view
    findViewById(R.id.status_image).setVisibility(View.GONE);
    //remove focus from status
    findViewById(R.id.status).clearFocus();
    findViewById(R.id.focus_layout).requestFocus();
    //reset autocomplete view
    ((AutoCompleteTextView)findViewById(R.id.status)).setText("");
    ((AutoCompleteTextView)findViewById(R.id.status)).setHint("Post something....");
    ((AutoCompleteTextView)findViewById(R.id.status)).setEnabled(true);

    //status class data reset
    newStatus.type=Status.TEXT;
    newStatus.image="null";
    newStatus.text="";
    newStatus.hasImage=false;
    newStatus.time="";

  }
  public void setUpPostStatus()
  {
    newStatus=new Status();
    resetPostStatus();
    findViewById(R.id.post_status_buttons).findViewById(R.id.cancel_action).setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View view)
      {
        resetPostStatus();
      }
    });

    (findViewById(R.id.status)).setOnFocusChangeListener(new View.OnFocusChangeListener() {
      @Override
      public void onFocusChange(View view, boolean b) {
        if (b)
        {
          findViewById(R.id.post_status_buttons).findViewById(R.id.cancel_action).setVisibility(View.VISIBLE);
        }
      }
    });

    findViewById(R.id.post_status_buttons).findViewById(R.id.ok_action).setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View view)
      {
        //post text status
        postStatus();

      }
    });
  }

  public void postStatus()
  {
    try {

      newStatus.text=((AutoCompleteTextView)findViewById(R.id.status)).getText().toString();
      if (newStatus.text.length()<3)
      {
        log.setText("Status has to be greater than 3 characters!!!");
        return;
      }
      newStatus.text=newStatus.text.trim();

      java.util.Date d=new java.util.Date();
      Timestamp timestamp=new Timestamp(d.getTime());
      newStatus.time=timestamp.toString();
      newStatus.type=Status.TEXT;

      log.setText("Posting your status...");
      findViewById(R.id.loading_feed_progress).setVisibility(View.VISIBLE);

      StringRequest putRequest = new StringRequest(Method.POST, Utility.siteUrl+"/post_status.php",
          new Response.Listener<String>()
          {
            @Override
            public void onResponse(String response)
            {
              // response
              try {
                JSONObject obj=new JSONObject(response);
                findViewById(R.id.loading_feed_progress).setVisibility(View.GONE);
                if (obj.getBoolean("success"))
                {

                  log.setText(obj.getString("message"));
                  //update feeds
                  getFeedsFromServer();
                  resetPostStatus();
                }else
                  {
                  log.setText(obj.getString("message"));
                }
              } catch (Exception e)
              {
                e.printStackTrace();
                log.setText("Exception occured while loading posts Exception:"+e.getMessage());
              }
            }
          },
          new Response.ErrorListener()
          {
            @Override
            public void onErrorResponse(VolleyError error) {
              log.setText("Error response:"+error.getMessage());
            }
          }
      ) {

        @Override
        protected Map<String, String> getParams()
        {
          Map<String, String>  params = new HashMap<>();
          params.put("type",newStatus.type);
          params.put("text",newStatus.text);
          params.put("image","none");
          params.put("time",newStatus.time);
          params.put("isremoved","n");
          params.put("username",TinyDB.getInstance().getString("username"));
          return params;
        }

      };

      RequestQueue requestQueue= Volley.newRequestQueue(this);
      requestQueue.add(putRequest);
      requestQueue.start();
    } catch (Exception e)
    {
      e.printStackTrace();
    }
  }


  public void setUpNavDrawer()
  {
    drawer=findViewById(R.id.drawer);
    //default closed
    drawer.animate().translationXBy(-getResources().getDisplayMetrics().widthPixels);
    findViewById(R.id.toggle_nav_drawer).setOnClickListener(new OnClickListener() {
      @Override
      public void onClick(final View view)
      {
        isDrawerOpen=true;
        drawer.animate().translationX(0);
      }
    });


    drawer.findViewById(R.id.closing_area).setOnClickListener(new OnClickListener() {
      @Override
      public void onClick(View v)
      {
        drawer.animate().translationXBy(-getResources().getDisplayMetrics().widthPixels);
      }
    });


    //drawer item clicks
    //open profile
    drawer.findViewById(R.id.profile).setOnClickListener(new OnClickListener() {
      @Override
      public void onClick(View v)
      {
        //open profile
        startActivity(new Intent(Show_Feeds.this,UserProfile.class));
      }
    });

    //open messages
    drawer.findViewById(R.id.message).setOnClickListener(new OnClickListener() {
      @Override
      public void onClick(View v)
      {
        //open message activity
        startActivity(new Intent(Show_Feeds.this,ShowFriendsToStartMessage.class));
      }
    });

    //logout
    drawer.findViewById(R.id.logout).setOnClickListener(new OnClickListener() {
      @Override
      public void onClick(View v) {
        logout();
      }
    });

  }

  protected void logout()
  {
    TinyDB.getInstance().putBoolean("isLoggedIn",false);
    TinyDB.getInstance().putString ("username","none");
    Toast.makeText(getApplicationContext(),"Logging out",Toast.LENGTH_LONG).show();
    startActivity(new Intent(Show_Feeds.this,Login_Manager.class));
  }

  @Override
  public void onBackPressed()
  {
    if (isDrawerOpen)
    {
      drawer.animate().translationXBy(-getResources().getDisplayMetrics().widthPixels);
    }else{

      finish();
    }
  }


}
