package com.hotdudehvfun.asocial;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.android.volley.Request.Method;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.Response.ErrorListener;
import com.android.volley.Response.Listener;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.NetworkImageView;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ViewPost extends AppCompatActivity {



  //id0 type1 text2 image3 time4 username5 isremoved6 name7 photo8
  JSONArray postData;
  EditText addCommentView;
  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_view_post);
    getPostData();
    getCommentsOnPost();

    bindEvents();
  }

  public void bindEvents()
  {
    addCommentView=findViewById(R.id.add_comment_view);
    findViewById(R.id.add_comment_button).setOnClickListener(new OnClickListener() {
      @Override
      public void onClick(View v)
      {
        if (addCommentView.getText().toString().trim().length()>0)
          addComment(addCommentView.getText().toString().trim());
        else
          Utility.sb(findViewById(R.id.parent),"At least write something before discussing!");
      }
    });
  }

  public void getCommentsOnPost()
  {
    try {
      StringRequest putRequest = new StringRequest(Method.POST, Utility.siteUrl+"/getCommentsOfPost.php",
          new Response.Listener<String>()
          {
            @Override
            public void onResponse(String response)
            {
              // response
              try {
                JSONObject obj=new JSONObject(response);
                if (obj.getBoolean("success"))
                {
                  createCommentLayouts(obj.getJSONArray("list"));
                }
              } catch (Exception e)
              {
                e.printStackTrace();
              }
            }
          },
          new Response.ErrorListener()
          {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
          }
      ) {

        @Override
        protected Map<String, String> getParams()
        {
          Map<String, String>  params = new HashMap<>();
          try {
            params.put("postId",String.valueOf(postData.getInt(0)));
          } catch (JSONException e) {
            e.printStackTrace();
          }
          return params;
        }

      };

      RequestQueue requestQueue= Volley.newRequestQueue(this);
      requestQueue.add(putRequest);
      requestQueue.start();
    } catch (Exception e)
    {
      e.printStackTrace();
    }
  }


  public void createCommentLayouts(JSONArray postArray)
  {
    try {
      LinearLayout container=findViewById(R.id.comment_container);
      container.removeAllViews();
      for (int i = 0; i <postArray.length() ; i++)
      {
        JSONArray row=postArray.getJSONArray(i);
        //id0 author1 postId2 text3 isRemoved4 time5 name6 photo7
        LinearLayout child= (LinearLayout) getLayoutInflater().inflate(R.layout.group_chat_message_other_person,null);

        Show_Feeds.loadImageFromURL(Utility.siteUrl+row.getString(7),(NetworkImageView) child.findViewById(R.id.photo));
        ((TextView)child.findViewById(R.id.user_name)).setText(row.getString(6));
        ((TextView)child.findViewById(R.id.time)).setText(row.getString(5));
        ((TextView)child.findViewById(R.id.text)).setText(row.getString(3));

        container.addView(child);
      }
    } catch (JSONException e) {
      e.printStackTrace();
    }
  }

  public void getPostData()
  {
    try {
      //tool bar setup
      Utility.setText(this,R.id.toolbar_title,"Add comment");
      //file data in ui
      postData=new JSONArray(getIntent().getStringExtra("jsonArray"));
      Utility.setText(this,R.id.name,postData.getString(7));
      Utility.setText(this,R.id.date,postData.getString(4));
      Utility.setText(this,R.id.text,postData.getString(2));

      Show_Feeds.loadImageFromURL(Utility.siteUrl+postData.getString(8),(NetworkImageView) findViewById(R.id.user_picture));

    } catch (JSONException e) {
      e.printStackTrace();
    }
  }

  public void addComment(final String text)
  {
    try {
      addCommentView.setEnabled(false);
      StringRequest putRequest = new StringRequest(Method.POST, Utility.siteUrl+"/addComment.php",
          new Listener<String>()
          {
            @Override
            public void onResponse(String response) {
              // response
              Log.d("#info",response);
              try {
                JSONObject obj=new JSONObject(response);
                if (obj.getBoolean("success"))
                {
                  //on success
                  getCommentsOnPost();
                  addCommentView.setText("");
                }
                else {
                  //on failure
                  Utility.sb(findViewById(R.id.parent),"Error occurred "+obj.getString("message"));
                }
              } catch (Exception e)
              {
                e.printStackTrace();
                Utility.sb(findViewById(R.id.parent),"Error occurred "+e.getMessage());

              }
            }
          },
          new ErrorListener()
          {
            @Override
            public void onErrorResponse(VolleyError e)
            {
              Utility.sb(findViewById(R.id.parent),"Error occurred "+e.getMessage());
            }
          }
      ) {

        @Override
        protected Map<String, String> getParams()
        {
          Map<String, String>  params = new HashMap<>();
          try {
            params.put("author",TinyDB.getInstance().getString("username"));
            params.put("postId", String.valueOf(postData.getInt(0)));
            params.put("text",text);

          } catch (JSONException e) {
            e.printStackTrace();
          }

          return params;
        }

      };

      RequestQueue requestQueue= Volley.newRequestQueue(this);
      requestQueue.add(putRequest);
      requestQueue.start();
    } catch (Exception e)
    {
      e.printStackTrace();
      Utility.sb(findViewById(R.id.parent),"Error occurred "+e.getMessage());

    }
  }

}
