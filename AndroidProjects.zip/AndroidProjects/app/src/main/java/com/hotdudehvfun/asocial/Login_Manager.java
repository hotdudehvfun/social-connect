package com.hotdudehvfun.asocial;

import android.content.Intent;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.android.volley.Request.Method;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;

import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONObject;


public class Login_Manager extends AppCompatActivity {

    boolean allowLogin;
    String username,password,confirmPassword;
    boolean userWantsToSignUp=false;
    TextView loginButton,signUpButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_manager_layout);

        //global vars
        allowLogin=true;
        TinyDB.getInstance().init(getApplicationContext());

        //bind events
        bindEvents();

        //hide confirm password
        findViewById(R.id.confirm_password).setVisibility(View.GONE);

        //check if user is logged in
      //checkIfUserIsLoggedIn();

    }

    public void checkIfUserIsLoggedIn()
    {
        boolean isLoggedIn=TinyDB.getInstance().getBoolean("isLoggedIn");
        if (isLoggedIn)
        {
            //proceed to home
            proceedToHome();
        }
    }

    public void proceedToHome()
    {
        startActivity(new Intent(Login_Manager.this,Show_Feeds.class));

    }
    public void bindEvents()
    {
      loginButton=findViewById(R.id.login_button);
      signUpButton=findViewById(R.id.signup_button);

        //log in
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                if (userWantsToSignUp)
                {
                    //back to login state
                    userWantsToSignUp=false;
                    setFieldForLogin();
                }else{
                    //use button for login
                    username=((EditText)findViewById(R.id.username)).getText().toString().trim();
                    password=((EditText)findViewById(R.id.password)).getText().toString().trim();
                    boolean hasError=false;
                    String msg="";
                    if (username.length()==0)
                    {
                        msg="Username is required to login!!!";
                        hasError=true;
                    }
                    if (password.length()==0)
                    {
                        msg="You cannot login without password!!!";
                        hasError=true;
                    }

                    Utility.sb(findViewById(R.id.parent),msg);
                    if (!hasError && allowLogin)
                    {
                      LoginUser();
                    }
                }
            }
        });
        //sign up
        signUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                if (!userWantsToSignUp)
                {
                    userWantsToSignUp = true;
                    //login becomes back to login
                    loginButton.setText("BACK TO LOG IN");

                    //new user becomes sign up
                    signUpButton.setText("SIGN UP");

                    setFieldForSignUp();
                }else {
                    //use button for login
                    username=((EditText)findViewById(R.id.username)).getText().toString().trim();
                    password=((EditText)findViewById(R.id.password)).getText().toString().trim();
                    confirmPassword=((EditText)findViewById(R.id.confirm_password)).getText().toString().trim();
                    boolean hasError=false;
                    String msg="";
                    if (confirmPassword.compareTo(password)!=0)
                    {
                        hasError=true;
                        msg="Confirm password is not equal to entered password";
                    }
                    if (username.length()==0)
                    {
                      msg="Username cannot be empty!";
                        hasError=true;
                    }
                    if (password.length()==0)
                    {
                      msg="Password is required to sign up!";
                        hasError=true;
                    }
                    Utility.sb(findViewById(R.id.parent),msg);
                    if (!hasError)
                    {
                        //sign up function here
                        SignUpNewUser();
                    }
                }
            }
        });
    }

    public void setFieldForSignUp()
    {
        ((TextView)findViewById(R.id.username)).setText("");
        ((TextView)findViewById(R.id.password)).setText("");
        ((TextView)findViewById(R.id.confirm_password)).setText("");
        findViewById(R.id.confirm_password).setVisibility(View.VISIBLE);
    }
    public void setFieldForLogin()
    {
        ((TextView)findViewById(R.id.username)).setText("");
        ((TextView)findViewById(R.id.password)).setText("");
        ((TextView)findViewById(R.id.confirm_password)).setText("");
        findViewById(R.id.confirm_password).setVisibility(View.GONE);
        loginButton.setText("LOG IN");
        signUpButton.setText("NEW USER?");
    }

    public void disableLoginButton()
    {
      try {
        allowLogin=false;
        loginButton.setBackgroundResource(R.drawable.chip_accent);
        loginButton.setText("Logging in...");
        loginButton.setTextColor(ContextCompat.getColor(this,R.color.white));
      } catch (Exception e)
      {
        e.printStackTrace();
        Utility.sb(findViewById(R.id.parent),"Error Cannot disbable logging button"+e.getMessage());
      }
    }
    public void enableLoginButton()
    {
      try {
        allowLogin=true;
        loginButton.setEnabled(true);
        loginButton.setBackgroundResource(R.drawable.chip_white);
        loginButton.setText("LOGIN");
        loginButton.setTextColor(ContextCompat.getColor(this,R.color.colorAccent));
      } catch (Exception e)
      {
        e.printStackTrace();
        Utility.sb(findViewById(R.id.parent),"Error while enabling logging button"+e.getMessage());
      }

    }
    public void LoginUser()
    {
    try {
      Utility.sb(findViewById(R.id.parent),"Please wait...Logging you in.");
      disableLoginButton();

      StringRequest putRequest = new StringRequest(Method.POST, Utility.siteUrl+"/login.php",
          new Response.Listener<String>()
          {
            @Override
            public void onResponse(String response) {
              // response
              try {
                JSONObject obj=new JSONObject(response);
                if (obj.getBoolean("success"))
                {
                  disableLoginButton();
                  Utility.sb(findViewById(R.id.parent),obj.getString("message"));
                  TinyDB.getInstance().putBoolean("isLoggedIn",true);
                  TinyDB.getInstance().putString("username",obj.getString("username"));
                  TinyDB.getInstance().putString("name",obj.getString("name"));
                  TinyDB.getInstance().putString("photo",obj.getString("photo"));
                  proceedToHome();
                }else{
                  Utility.sb(findViewById(R.id.parent),obj.getString("message"));
                }
              } catch (Exception e)
              {
                e.printStackTrace();
                Utility.sb(findViewById(R.id.parent),"Exception occured while logging Exception:"+e.getMessage());
              }
            }
          },
          new Response.ErrorListener()
          {
            @Override
            public void onErrorResponse(VolleyError error) {
              Utility.sb(findViewById(R.id.parent),"Error response:"+error.getMessage());
            }
          }
      ) {

        @Override
        protected Map<String, String> getParams()
        {
          Map<String, String>  params = new HashMap<String, String> ();
          params.put("username", username);
          params.put("password", password);
          return params;
        }

      };

      RequestQueue requestQueue= Volley.newRequestQueue(this);
      requestQueue.add(putRequest);
      requestQueue.start();
    } catch (Exception e)
    {
      e.printStackTrace();
    }
    enableLoginButton();
  }
  public void SignUpNewUser()
  {
    try {
      Utility.sb(findViewById(R.id.parent),"Please wait...Logging in.");

      StringRequest putRequest = new StringRequest(Method.POST, Utility.siteUrl+"/signup.php",
          new Response.Listener<String>()
          {
            @Override
            public void onResponse(String response) {
              // response
              try {
                JSONObject obj=new JSONObject(response);
                if (obj.getBoolean("success"))
                {
                  Utility.sb(findViewById(R.id.parent),obj.getString("message"));
                  TinyDB.getInstance().putBoolean("isLoggedIn",true);
                  TinyDB.getInstance().putString("username",obj.getString("username"));
                  TinyDB.getInstance().putString("name",obj.getString("name"));
                  proceedToHome();
                }else{
                  Utility.sb(findViewById(R.id.parent),obj.getString("message"));
                }
              } catch (Exception e)
              {
                Utility.sb(findViewById(R.id.parent),"Exception occured while sign up Exception:"+e.getMessage());
                e.printStackTrace();
              }
            }
          },
          new Response.ErrorListener()
          {
            @Override
            public void onErrorResponse(VolleyError error) {
              Utility.sb(findViewById(R.id.parent),"Error response:"+error.getMessage());
            }
          }
      ) {

        @Override
        protected Map<String, String> getParams()
        {
          Map<String, String>  params = new HashMap<String, String> ();
          params.put("username", username);
          params.put("password", password);
          return params;
        }

      };

      RequestQueue requestQueue= Volley.newRequestQueue(this);
      requestQueue.add(putRequest);
      requestQueue.start();
    } catch (Exception e)
    {
      e.printStackTrace();
    }
  }


}