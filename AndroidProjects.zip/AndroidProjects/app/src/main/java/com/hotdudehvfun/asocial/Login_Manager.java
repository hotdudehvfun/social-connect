package com.hotdudehvfun.asocial;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Pair;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.Request.Method;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;

import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;


public class Login_Manager extends AppCompatActivity {

    TextView log;
    boolean allowLogin;
    String username,password,confirmPassword;
    boolean userWantsToSignUp=false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_manager_layout);

        //global vars
        log=findViewById(R.id.log);
        log.setText("");
        allowLogin=true;
        TinyDB.getInstance().init(getApplicationContext());

        //bind events
        bindEvents();

        //hide confirm password
        findViewById(R.id.confirm_password).setVisibility(View.GONE);

        //check if user is logged in
      //checkIfUserIsLoggedIn();

    }

    public void checkIfUserIsLoggedIn()
    {
        boolean isLoggedIn=TinyDB.getInstance().getBoolean("isLoggedIn");
        if (isLoggedIn)
        {
            //proceed to home
            proceedToHome();
        }
    }

    public void proceedToHome()
    {
        startActivity(new Intent(Login_Manager.this,Show_Feeds.class));

    }
    public void bindEvents()
    {
        //log in
        findViewById(R.id.login_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                if (userWantsToSignUp)
                {
                    //back to login state
                    userWantsToSignUp=false;
                    setFieldForLoggin();
                }else{
                    //use button for login
                    username=((EditText)findViewById(R.id.username)).getText().toString().trim();
                    password=((EditText)findViewById(R.id.password)).getText().toString().trim();
                    boolean hasError=false;
                    if (username.length()==0)
                    {
                        log.setText("Username cannot be empty!");
                        hasError=true;
                    }
                    if (password.length()==0)
                    {
                        log.setText("Password is required to log in!");
                        hasError=true;
                    }
                    if (!hasError)
                        LoginUser();

                }


            }
        });
        //sign up
        findViewById(R.id.signup_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                if (!userWantsToSignUp)
                {
                    userWantsToSignUp = true;
                    //login becomes back to login
                    ((TextView) findViewById(R.id.login_button)).setText("BACK TO LOG IN");

                    //new user becomes sign up
                    ((TextView) findViewById(R.id.signup_button)).setText("SIGN UP");

                    setFieldForSignUp();
                }else {
                    //use button for login
                    username=((EditText)findViewById(R.id.username)).getText().toString().trim();
                    password=((EditText)findViewById(R.id.password)).getText().toString().trim();
                    confirmPassword=((EditText)findViewById(R.id.confirm_password)).getText().toString().trim();
                    boolean hasError=false;
                    if (confirmPassword.compareTo(password)!=0)
                    {
                        hasError=true;
                        log.setText("Confirm password is not equal to entered password");
                    }
                    if (username.length()==0)
                    {
                        log.setText("Username cannot be empty!");
                        hasError=true;
                    }
                    if (password.length()==0)
                    {
                        log.setText("Password is required to sign up!");
                        hasError=true;
                    }
                    if (!hasError)
                    {
                        //sign up function here
                        SignUpNewUser();
                    }
                }
            }
        });
    }

    public void setFieldForSignUp()
    {
        float factor=-180;
        findViewById(R.id.username).animate().translationYBy(factor);
        findViewById(R.id.password).animate().translationYBy(factor);
        findViewById(R.id.confirm_password).animate().translationYBy(factor);

        ((TextView)findViewById(R.id.username)).setText("");
        ((TextView)findViewById(R.id.password)).setText("");
        ((TextView)findViewById(R.id.confirm_password)).setText("");

        findViewById(R.id.confirm_password).setVisibility(View.VISIBLE);
    }
    public void setFieldForLoggin()
    {
        float factor=180;
        findViewById(R.id.username).animate().translationYBy(factor);
        findViewById(R.id.password).animate().translationYBy(factor);
        findViewById(R.id.confirm_password).animate().translationYBy(factor);
        ((TextView)findViewById(R.id.username)).setText("");
        ((TextView)findViewById(R.id.password)).setText("");
        ((TextView)findViewById(R.id.confirm_password)).setText("");
        findViewById(R.id.confirm_password).setVisibility(View.GONE);
        ((TextView)findViewById(R.id.login_button)).setText("LOG IN");
        ((TextView)findViewById(R.id.signup_button)).setText("NEW USER?");


    }

    public void LoginUser()
    {
    try {
      log.setText("Please wait...Logging in.");

      StringRequest putRequest = new StringRequest(Method.POST, Utility.siteUrl+"/login.php",
          new Response.Listener<String>()
          {
            @Override
            public void onResponse(String response) {
              // response
              try {
                JSONObject obj=new JSONObject(response);
                if (obj.getBoolean("success"))
                {
                  log.setText(obj.getString("message"));
                  TinyDB.getInstance().putBoolean("isLoggedIn",true);
                  TinyDB.getInstance().putString("username",obj.getString("username"));
                  TinyDB.getInstance().putString("name",obj.getString("name"));
                  TinyDB.getInstance().putString("photo",obj.getString("photo"));
                  proceedToHome();
                }else{
                  log.setText(obj.getString("message"));
                }
              } catch (Exception e)
              {
                e.printStackTrace();
                log.setText("Exception occured while logging Exception:"+e.getMessage());
              }
            }
          },
          new Response.ErrorListener()
          {
            @Override
            public void onErrorResponse(VolleyError error) {
              log.setText("Error response:"+error.getMessage());
            }
          }
      ) {

        @Override
        protected Map<String, String> getParams()
        {
          Map<String, String>  params = new HashMap<String, String> ();
          params.put("username", username);
          params.put("password", password);
          return params;
        }

      };

      RequestQueue requestQueue= Volley.newRequestQueue(this);
      requestQueue.add(putRequest);
      requestQueue.start();
    } catch (Exception e)
    {
      e.printStackTrace();
    }
  }
  public void SignUpNewUser()
  {
    try {
      log.setText("Please wait...Logging in.");

      StringRequest putRequest = new StringRequest(Method.POST, Utility.siteUrl+"/signup.php",
          new Response.Listener<String>()
          {
            @Override
            public void onResponse(String response) {
              // response
              try {
                JSONObject obj=new JSONObject(response);
                if (obj.getBoolean("success"))
                {
                  log.setText(obj.getString("message"));
                  TinyDB.getInstance().putBoolean("isLoggedIn",true);
                  TinyDB.getInstance().putString("username",obj.getString("username"));
                  TinyDB.getInstance().putString("name",obj.getString("name"));
                  proceedToHome();
                }else{
                  log.setText(obj.getString("message"));
                }
              } catch (Exception e)
              {
                e.printStackTrace();
                log.setText("Exception occured while sign up Exception:"+e.getMessage());
              }
            }
          },
          new Response.ErrorListener()
          {
            @Override
            public void onErrorResponse(VolleyError error) {
              log.setText("Error response:"+error.getMessage());
            }
          }
      ) {

        @Override
        protected Map<String, String> getParams()
        {
          Map<String, String>  params = new HashMap<String, String> ();
          params.put("username", username);
          params.put("password", password);
          return params;
        }

      };

      RequestQueue requestQueue= Volley.newRequestQueue(this);
      requestQueue.add(putRequest);
      requestQueue.start();
    } catch (Exception e)
    {
      e.printStackTrace();
    }
  }


}