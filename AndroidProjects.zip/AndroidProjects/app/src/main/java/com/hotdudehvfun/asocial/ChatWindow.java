package com.hotdudehvfun.asocial;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.Request.Method;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

//todo implement get recent chat users.. complete php file
public class ChatWindow extends AppCompatActivity {

  EditText input_field;
  RelativeLayout sendButton;
  String recipient,photo,name;
  @Override
  protected void onCreate(Bundle savedInstanceState) {
    try
    {
      super.onCreate(savedInstanceState);
      setContentView(R.layout.activity_chat_window);

      input_field=findViewById(R.id.input_message);
      sendButton=findViewById(R.id.send_button);

      recipient=getIntent().getStringExtra("person-username");
      photo=getIntent().getStringExtra("person-photo");
      name=getIntent().getStringExtra("person-name");

      ((TextView)findViewById(R.id.toolbar_title)).setText(name);
      bindEvents();
      loadMessages();
    } catch (Exception e)
    {
      e.printStackTrace();
    }


  }
  public void bindEvents()
  {
    //send button
    sendButton.setOnClickListener(new OnClickListener() {
      @Override
      public void onClick(View v)
      {
        if (input_field.getText().length()>0)
        {
          sendMessage(input_field.getText().toString());
        }
      }
    });

    //back button
    findViewById(R.id.chatWindowToolbar).findViewById(R.id.back_button).setOnClickListener(
        new OnClickListener() {
          @Override
          public void onClick(View v) {
            finish();
          }
        });
  }
  public void sendMessage(final String msg)
  {
    try {

      input_field.setEnabled(false);
      StringRequest putRequest = new StringRequest(Method.POST, Utility.siteUrl+"/sendMessage.php",
          new Response.Listener<String>()
          {
            @Override
            public void onResponse(String response) {
              // response
              try {
                JSONObject obj=new JSONObject(response);
                if (obj.getBoolean("success"))
                {
                  //load messages
                  input_field.setText("");
                  input_field.setEnabled(true);
                  loadMessages();
                }else{
                  Log.d("#info","sending failed");
                }
              } catch (Exception e)
              {
                e.printStackTrace();
                Toast.makeText(ChatWindow.this,"Exception while sending message:"+e.getMessage(),Toast.LENGTH_LONG).show();
              }
            }
          },
          new Response.ErrorListener()
          {
            @Override
            public void onErrorResponse(VolleyError error) {
              Toast.makeText(ChatWindow.this,"Error in respone while sending message:"+error.getMessage(),Toast.LENGTH_LONG).show();
            }
          }
      ) {

        @Override
        protected Map<String, String> getParams()
        {
          Map<String, String>  params = new HashMap<String, String>();
          params.put("message",msg);
          params.put("author",TinyDB.getInstance().getString("username"));
          params.put("recipient",recipient);
          return params;
        }

      };

      RequestQueue requestQueue= Volley.newRequestQueue(this);
      requestQueue.add(putRequest);
      requestQueue.start();
    } catch (Exception e)
    {
      e.printStackTrace();
    }
  }

  public void createMessagesLayouts(JSONArray postArray)
  {
    try {
      LinearLayout messageContainer=findViewById(R.id.message_container);
      messageContainer.removeAllViews();
      for (int i = 0; i <postArray.length() ; i++)
      {
        JSONArray row=postArray.getJSONArray(i);
        //id0 message1 isremoved2 author3 recipient4 time5



        //messages created by other person
        if (row.getString(3).compareToIgnoreCase(recipient)==0)
        {
           RelativeLayout  child= (RelativeLayout) getLayoutInflater().inflate(R.layout.message_receive_layout,null);
          ((TextView)child.findViewById(R.id.text)).setText(row.getString(1));
          messageContainer.addView(child);

        }else if(row.getString(3).compareToIgnoreCase(TinyDB.getInstance().getString("username"))==0)
        {
          RelativeLayout child= (RelativeLayout) getLayoutInflater().inflate(R.layout.message_sent_layout,null);
          ((TextView)child.findViewById(R.id.text)).setText(row.getString(1));
          messageContainer.addView(child);

        }
      }
    } catch (JSONException e) {
      e.printStackTrace();
    }
  }

  public void loadMessages()
  {
    try {

      Log.d("#info","Loading messages...");
      StringRequest putRequest = new StringRequest(Method.POST, Utility.siteUrl+"/loadMessages.php",
          new Response.Listener<String>()
          {
            @Override
            public void onResponse(String response)
            {
              // response
              try {
                JSONObject obj=new JSONObject(response);
                Log.d("#info",response);
                if (obj.getBoolean("success"))
                {
                  //create layouts
                  createMessagesLayouts(obj.getJSONArray("sentMessages"));
                }else
                  {
                  Log.d("#info","load messages failed");
                }
              } catch (Exception e)
              {
                e.printStackTrace();
              }
            }
          },
          new Response.ErrorListener()
          {
            @Override
            public void onErrorResponse(VolleyError error)
            {
              error.printStackTrace();
            }
          }
      ) {

        @Override
        protected Map<String, String> getParams()
        {
          Map<String, String>  params = new HashMap<String, String>();
          params.put("author",TinyDB.getInstance().getString("username"));
          params.put("recipient",recipient);
          return params;
        }

      };

      RequestQueue requestQueue= Volley.newRequestQueue(this);
      requestQueue.add(putRequest);
      requestQueue.start();
    } catch (Exception e)
    {
      e.printStackTrace();
    }

  }


}
