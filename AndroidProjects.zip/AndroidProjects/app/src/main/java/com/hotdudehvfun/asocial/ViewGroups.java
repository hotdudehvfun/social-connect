package com.hotdudehvfun.asocial;

import android.content.Intent;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.Request.Method;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.NetworkImageView;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ViewGroups extends AppCompatActivity {

  TextView log,groupNameView;
  View createGroupFab;
  View popUp;
  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_view_groups);
    log=findViewById(R.id.log);
    getGroupList();
    bindEvents();
  }

  public void bindEvents()
  {
    createGroupFab=findViewById(R.id.create_group);
    popUp=findViewById(R.id.create_group_pop_up_include);
    groupNameView=popUp.findViewById(R.id.group_name);
    //open create group popup
    createGroupFab.setOnClickListener(new OnClickListener() {
      @Override
      public void onClick(View v)
      {
        openCreateGroupPopUp();
      }
    });

    popUp.findViewById(R.id.cancel_action).setOnClickListener(new OnClickListener() {
      @Override
      public void onClick(View v) {
        closeCreateGroupPopUp();
      }
    });

    popUp.findViewById(R.id.ok_action).setOnClickListener(new OnClickListener() {
      @Override
      public void onClick(View v)
      {
        if (groupNameView.getText().toString().trim().length()>0)
        {
          createNewGroup();
        }
      }
    });

  }

  public void openCreateGroupPopUp()
  {
    popUp.setVisibility(View.VISIBLE);
  }
  public void closeCreateGroupPopUp()
  {
    popUp.setVisibility(View.GONE);
  }

  public void createNewGroup()
  {
    try
    {
      ((TextView)popUp.findViewById(R.id.log)).setText("Creating new group please wait...");
      StringRequest putRequest = new StringRequest(Method.POST, Utility.siteUrl+"/createNewGroup.php",
          new Response.Listener<String>()
          {
            @Override
            public void onResponse(String response) {
              // response
              try
              {
                Log.d("#info",response);
                JSONObject obj=new JSONObject(response);
                ((TextView)popUp.findViewById(R.id.log)).setText(obj.getString("createMessage")+"\n"+obj.getString("adminMessage"));
                if (obj.getBoolean("isCreated"))
                {
                  if (obj.getBoolean("isAdmin"))
                  {
                    closeCreateGroupPopUp();
                    getGroupList();
                  }
                }else
                {
                  ((TextView)popUp.findViewById(R.id.log)).setText(obj.getString("createMessage"));
                }
              } catch (Exception e)
              {
                e.printStackTrace();
              }
            }
          },
          new Response.ErrorListener()
          {
            @Override
            public void onErrorResponse(VolleyError error)
            {
              ((TextView)popUp.findViewById(R.id.log)).setText("Error while creating new group  list: Error is:"+error.getMessage());
            }
          }
      ) {

        @Override
        protected Map<String, String> getParams()
        {
          Map<String, String>  params = new HashMap<>();
          params.put("admin",TinyDB.getInstance().getString("username"));
          params.put("groupName",groupNameView.getText().toString().trim());
          return params;
        }

      };

      RequestQueue requestQueue= Volley.newRequestQueue(this);
      requestQueue.add(putRequest);
      requestQueue.start();

    }catch (Exception e)
    {
      e.printStackTrace();

    }
  }

  public void getGroupList()
  {
    try
    {
      log.setText("Getting your groups");
      StringRequest putRequest = new StringRequest(Method.POST, Utility.siteUrl+"/getGroupsList.php",
          new Response.Listener<String>()
          {
            @Override
            public void onResponse(String response) {
              // response
              try
              {
                Log.d("#info",response);
                JSONObject obj=new JSONObject(response);
                if (obj.getBoolean("success"))
                {
                  if (obj.getInt("rowCount")>0)
                  {
                    createGroupListLayout(obj.getJSONArray("list"));
                  }
                }
              } catch (Exception e)
              {
                e.printStackTrace();
              }
            }
          },
          new Response.ErrorListener()
          {
            @Override
            public void onErrorResponse(VolleyError error)
            {
              Toast.makeText(ViewGroups.this,"Error while getting friend list: Error is:"+error.getMessage(),Toast.LENGTH_LONG);
            }
          }
      ) {

        @Override
        protected Map<String, String> getParams()
        {
          Map<String, String>  params = new HashMap<String, String>();
          params.put("username",TinyDB.getInstance().getString("username"));
          return params;
        }

      };

      RequestQueue requestQueue= Volley.newRequestQueue(this);
      requestQueue.add(putRequest);
      requestQueue.start();

    }catch (Exception e)
    {
      e.printStackTrace();

    }
  }

  public void createGroupListLayout(JSONArray postArray)
  {
    try {
      LinearLayout feed_container=findViewById(R.id.groups_container);
      feed_container.removeAllViews();

      if (postArray.length()>0)
      {
        log.setText("You have "+postArray.length()+" groups!");
        for (int i = 0; i <postArray.length() ; i++)
        {
          JSONArray row=postArray.getJSONArray(i);
          //groupid0	username1	rights2	groupid3	admin4	groupname5	groupState6	photo7	time8
          LinearLayout child= (LinearLayout) getLayoutInflater().inflate(R.layout.one_friend_layout,null);
          child.findViewById(R.id.friend_request_action_container).setVisibility(View.GONE);
          ((TextView)child.findViewById(R.id.friendName)).setText(row.getString(5));

          Utility.getImage(getApplicationContext(),Utility.siteUrl+row.getString(7),
              (NetworkImageView) child.findViewById(R.id.friendProfileIcon));

          child.findViewById(R.id.parent).setTag(row.toString());
          child.findViewById(R.id.parent).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
              Intent intent=new Intent(ViewGroups.this,ChatWindowGroups.class);
              intent.putExtra("groupDataJson",view.getTag().toString());
              startActivity(intent);
            }
          });

          feed_container.addView(child);
        }
      }else{
        log.setText("You have no active group!");

      }


    } catch (JSONException e) {
      e.printStackTrace();
    }
  }
}
