package com.hotdudehvfun.asocial;

import android.content.DialogInterface;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;
import com.android.volley.Request.Method;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.NetworkImageView;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONObject;

public class PersonProfile extends AppCompatActivity {


  NetworkImageView coverPhoto,userProfilePhoto;
  String profileUsername,profileName,profilePhoto;
  TextView friendButton;
  String friendState;
  String changeFriendState,changeFriendStateMessage;
  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_person_profile);




    //load data into page
    userProfilePhoto=findViewById(R.id.user_profile_photo);
    coverPhoto=findViewById(R.id.user_cover_photo);
    profileUsername=getIntent().getStringExtra("person-username");
    profileName=getIntent().getStringExtra("person-name");
    profilePhoto=getIntent().getStringExtra("person-photo");
    friendButton=findViewById(R.id.add_as_friend_button);
    getFriendState();

    loadImageFromURL(Utility.siteUrl+profilePhoto,userProfilePhoto);
    loadImageFromURL("https://media.blendernation.com/wp-content/uploads/2017/12/20000_Subscribers_and_Free_Assets.jpg",coverPhoto);

    ((TextView)findViewById(R.id.user_full_name)).setText(profileName);

    bindEvents();

  }

  public void loadImageFromURL(String url,NetworkImageView imageView)
  {
    ImageLoader imageLoader=VolleyImageLoad.getInstance(this.getApplicationContext()).getImageLoader();
    imageLoader.get(url, ImageLoader.getImageListener(imageView,
        R.drawable.loading_image,
        android.R.drawable
            .ic_dialog_alert));
    imageView.setImageUrl(url,imageLoader);
  }

  public void getFriendState()
  {
    try {

      StringRequest putRequest = new StringRequest(Method.POST, Utility.siteUrl+"getFriendsState.php",
          new Response.Listener<String>()
          {
            @Override
            public void onResponse(String response)
            {
              // response
              try {
                JSONObject obj=new JSONObject(response);
                if (obj.getBoolean("success"))
                {
                  friendState=obj.getString("areFriends");
                  if (friendState.compareToIgnoreCase("y")==0)
                  {
                    friendButton.setText("Friends");
                    changeFriendState="n";
                    changeFriendStateMessage="Are you sure you want to UNFRIEND THIS user?";
                  }
                  if (friendState.compareToIgnoreCase("n")==0)
                  {
                    friendButton.setText("Add as Friend");
                    changeFriendState="p";
                    changeFriendStateMessage="Are you sure you want to friend this user?";
                  }
                  if (friendState.compareToIgnoreCase("v")==0)
                  {
                    friendButton.setText("Add as Friend");
                    changeFriendState="p";
                    changeFriendStateMessage="Are you sure you want to be FRIEND with this user?";
                  }
                  if (friendState.compareToIgnoreCase("p")==0)
                  {
                    friendButton.setText("Request Pending");
                    changeFriendState="n";
                    changeFriendStateMessage="Your friend request is pending! \n Are you sure you want to cancel friend request?";
                  }

                  friendButton.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                      handleFriendStateClick("Friend State Changer",changeFriendStateMessage);
                    }
                  });

                }else {
                }
              } catch (Exception e)
              {
                e.printStackTrace();
              }
            }
          },
          new Response.ErrorListener()
          {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
          }
      ) {

        @Override
        protected Map<String, String> getParams()
        {
          Map<String, String>  params = new HashMap<String, String>();
          params.put("username",TinyDB.getInstance().getString("username"));
          params.put("target",profileUsername);
          return params;
        }

      };

      RequestQueue requestQueue= Volley.newRequestQueue(this);
      requestQueue.add(putRequest);
      requestQueue.start();
    } catch (Exception e)
    {
      e.printStackTrace();
    }
  }

  public void handleFriendStateClick(String title,String message)
  {
    AlertDialog alertDialog = new AlertDialog.Builder(PersonProfile.this).create();
    alertDialog.setTitle(title);
    alertDialog.setMessage(message);
    alertDialog.setIcon(R.drawable.group_icon);
    alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "Cancel",
        new DialogInterface.OnClickListener() {
          @Override
          public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
          }
        });
    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
        new DialogInterface.OnClickListener() {
          public void onClick(DialogInterface dialog, int which)
          {
            setFriendState(changeFriendState);
            dialog.dismiss();
          }
        });
    alertDialog.show();
  }
  public void setFriendState(final String newState)
  {
    try {
      StringRequest putRequest = new StringRequest(Method.POST, Utility.siteUrl+"/updateFriendState.php",
          new Response.Listener<String>()
          {
            @Override
            public void onResponse(String response)
            {
              // response
              try {
                JSONObject obj=new JSONObject(response);
                Log.d("#info",response);
                if (obj.getBoolean("success"))
                {
                  //load new state
                  Snackbar.make(findViewById(R.id.parent),"Friend state changed :)",Snackbar.LENGTH_LONG).show();
                  getFriendState();
                }else {
                  Snackbar.make(findViewById(R.id.parent),"Error while updating friend state"+obj.getString("message"),Snackbar.LENGTH_LONG).show();
                }
              } catch (Exception e)
              {
                e.printStackTrace();
              }
            }
          },
          new Response.ErrorListener()
          {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
          }
      ) {

        @Override
        protected Map<String, String> getParams()
        {
          Map<String, String>  params = new HashMap<String, String>();
          params.put("username",TinyDB.getInstance().getString("username"));
          params.put("target",profileUsername);
          params.put("newState",newState);
          params.put("oldState",friendState);
          return params;
        }

      };

      RequestQueue requestQueue= Volley.newRequestQueue(this);
      requestQueue.add(putRequest);
      requestQueue.start();
    } catch (Exception e)
    {
      e.printStackTrace();
    }
  }

  public void bindEvents()
  {

    userProfilePhoto=findViewById(R.id.user_profile_photo);
    coverPhoto=findViewById(R.id.user_cover_photo);
  }
}
