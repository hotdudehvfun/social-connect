package com.hotdudehvfun.asocial;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AutoCompleteTextView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.android.volley.Request.Method;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.NetworkImageView;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class SearchUser extends AppCompatActivity {

  AutoCompleteTextView searchBar;
  TextView log;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_search_user);


    bindEvents();
  }


  public void loadImageFromURL(String url,NetworkImageView imageView)
  {
    ImageLoader imageLoader=VolleyImageLoad.getInstance(this.getApplicationContext()).getImageLoader();
    imageLoader.get(url, ImageLoader.getImageListener(imageView,
        R.drawable.loading_image,
        android.R.drawable
            .ic_dialog_alert));
    imageView.setImageUrl(url,imageLoader);
  }
  public void createSearchResultLayouts(JSONArray postArray)
  {
    try {
      LinearLayout feed_container=findViewById(R.id.search_results);
      feed_container.removeAllViews();
      for (int i = 0; i <postArray.length() ; i++)
      {
        JSONArray row=postArray.getJSONArray(i);
        //username0 name1 photo2
        LinearLayout child= (LinearLayout) getLayoutInflater().inflate(R.layout.fragment_user_search_result,null);
        LinearLayout.LayoutParams lp= new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0,20,0,20);
        child.setLayoutParams(lp);
        loadImageFromURL(Utility.siteUrl+row.getString(2),((NetworkImageView)child.findViewById(R.id.user_picture)));
        ((TextView)child.findViewById(R.id.user_name)).setText(row.getString(1));

        child.setTag(row);

        child.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View view)
          {
            Intent intent=new Intent(SearchUser.this,PersonProfile.class);
            try {
              JSONArray temp=new JSONArray(view.getTag().toString());
              intent.putExtra("person-username",temp.getString(0));
              intent.putExtra("person-name",temp.getString(1));
              intent.putExtra("person-photo",temp.getString(2));
              startActivity(intent);
            } catch (JSONException e) {
              e.printStackTrace();
            }

          }
        });
        feed_container.addView(child);
      }
    } catch (JSONException e) {
      e.printStackTrace();
    }
  }
  public void getSearchResults(final String query)
  {
    try {
      log.setText("Searching....");
      findViewById(R.id.progressBar).setVisibility(View.VISIBLE);

      StringRequest putRequest = new StringRequest(Method.POST, Utility.siteUrl+"/searchUser.php",
          new Response.Listener<String>()
          {
            @Override
            public void onResponse(String response)
            {
              // response
              try {
                JSONObject obj=new JSONObject(response);
                if (obj.getBoolean("success"))
                {
                  log.setText(obj.getString("message"));
                  findViewById(R.id.progressBar).setVisibility(View.GONE);
                  createSearchResultLayouts(obj.getJSONArray("list"));

                }else {
                  log.setText(obj.getString("message"));
                }
              } catch (Exception e)
              {
                e.printStackTrace();
                log.setText("Exception occured while loading posts Exception:"+e.getMessage());
              }
            }
          },
          new Response.ErrorListener()
          {
            @Override
            public void onErrorResponse(VolleyError error) {
              log.setText("Error response:"+error.getMessage());
            }
          }
      ) {

        @Override
        protected Map<String, String> getParams()
        {
          Map<String, String>  params = new HashMap<String, String>();
          params.put("query",query);
          return params;
        }

      };

      RequestQueue requestQueue= Volley.newRequestQueue(this);
      requestQueue.add(putRequest);
      requestQueue.start();
    } catch (Exception e)
    {
      e.printStackTrace();
    }
  }
  public void bindEvents()
  {
    log=findViewById(R.id.log);
    searchBar=findViewById(R.id.search_user_bar);
    searchBar.addTextChangedListener(new TextWatcher() {
      @Override
      public void beforeTextChanged(CharSequence s, int start, int count, int after) {

      }

      @Override
      public void onTextChanged(CharSequence s, int start, int before, int count) {

      }

      @Override
      public void afterTextChanged(Editable s)
      {
        if (s.toString().length()>=2)
          getSearchResults(s.toString());
      }
    });
  }
}
