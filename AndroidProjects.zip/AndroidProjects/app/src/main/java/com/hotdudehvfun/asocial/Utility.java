package com.hotdudehvfun.asocial;

import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Point;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AlertDialog;
import android.text.Html;
import android.util.Log;
import android.view.Display;
import android.widget.TextView;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.NetworkImageView;

public class Utility
{
    public static String siteUrl="http://192.168.43.65/social/";

    public static void exceptionAlert(Context context, String message)
    {
        AlertDialog alertDialog = new AlertDialog.Builder(context).create();
        alertDialog.setTitle("Exception");
        alertDialog.setMessage(message.trim());
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        alertDialog.show();
    }

    public static void setHTML(TextView textView,String html)
    {
      if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N)
      {
        textView.setText(Html.fromHtml(html,Html.FROM_HTML_MODE_LEGACY));
      } else {
        textView.setText(Html.fromHtml(html));
      }
    }

  public static void getImage(Context context,String url,NetworkImageView imageView)
  {
    ImageLoader imageLoader=VolleyImageLoad.getInstance(context).getImageLoader();
    imageLoader.get(url, ImageLoader.getImageListener(imageView,
        R.drawable.loading_image,
        android.R.drawable
            .ic_dialog_alert));
    imageView.setImageUrl(url,imageLoader);
  }

}
