package com.hotdudehvfun.asocial;

import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Point;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.Display;

public class Utility
{
    public static String siteUrl="http://192.168.43.65/social/";

    public static void exceptionAlert(Context context, String message)
    {
        AlertDialog alertDialog = new AlertDialog.Builder(context).create();
        alertDialog.setTitle("Exception");
        alertDialog.setMessage(message.trim());
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        alertDialog.show();
    }


}
