package com.hotdudehvfun.asocial;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Environment;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.NetworkImageView;

class UserEntity
{
  public String username,name,photo;
  UserEntity(String u,String n,String p)
  {
    this.username=u;
    this.name=n;
    this.photo=p;
  }
}

public class Utility
{
    public static String siteUrl="http://192.168.43.65/social/";

    public static void exceptionAlert(Context context, String message)
    {
        AlertDialog alertDialog = new AlertDialog.Builder(context).create();
        alertDialog.setTitle("Exception");
        alertDialog.setMessage(message.trim());
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        alertDialog.show();
    }


    public static void sb(View view,String msg)
    {
      Snackbar.make(view,msg,Snackbar.LENGTH_LONG).show();
    }

  public static void getImage(Context context,String url,NetworkImageView imageView)
  {
    ImageLoader imageLoader=VolleyImageLoad.getInstance(context).getImageLoader();
    imageLoader.get(url, ImageLoader.getImageListener(imageView,
        R.drawable.loading_image,
        android.R.drawable
            .ic_dialog_alert));
    imageView.setImageUrl(url,imageLoader);
  }


  public static boolean isExternalStorageWritable() {
    String state = Environment.getExternalStorageState();
    if (Environment.MEDIA_MOUNTED.equals(state)) {
      return true;
    }
    return false;
  }

  public static boolean isExternalStorageReadable() {
    String state = Environment.getExternalStorageState();
    if (Environment.MEDIA_MOUNTED.equals(state) ||
        Environment.MEDIA_MOUNTED_READ_ONLY.equals(state)) {
      return true;
    }
    return false;
  }

  public static void setText(AppCompatActivity appCompatActivity,int id,String text)
  {
    try {
      ((TextView)appCompatActivity.findViewById(id)).setText(text);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

}
