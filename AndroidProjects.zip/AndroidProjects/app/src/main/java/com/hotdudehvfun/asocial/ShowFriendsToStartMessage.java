package com.hotdudehvfun.asocial;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.Request.Method;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


// TODO: get friend list
public class ShowFriendsToStartMessage extends AppCompatActivity {

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_show_friends_to_start_message);

    getFriendList();

  }

  public void getFriendList()
  {
    try
    {

      StringRequest putRequest = new StringRequest(Method.POST, Utility.siteUrl+"/getFriendsList.php",
          new Response.Listener<String>()
          {
            @Override
            public void onResponse(String response) {
              // response
              try
              {
                Log.d("#info",response);
                JSONObject obj=new JSONObject(response);
                if (obj.getBoolean("success"))
                {
                  Log.d("#info",obj.getJSONArray("friendList").toString());
                  createFriendListLayout(obj.getJSONArray("friendList"));
                }
              } catch (Exception e)
              {
                e.printStackTrace();
              }
            }
          },
          new Response.ErrorListener()
          {
            @Override
            public void onErrorResponse(VolleyError error)
            {
              Toast.makeText(ShowFriendsToStartMessage.this,"Error while getting friend list: Error is:"+error.getMessage(),Toast.LENGTH_LONG);
            }
          }
      ) {

        @Override
        protected Map<String, String> getParams()
        {
          Map<String, String>  params = new HashMap<String, String>();
          params.put("username",TinyDB.getInstance().getString("username"));
          return params;
        }

      };

      RequestQueue requestQueue= Volley.newRequestQueue(this);
      requestQueue.add(putRequest);
      requestQueue.start();

    }catch (Exception e)
    {
      e.printStackTrace();

    }
  }

  public void createFriendListLayout(JSONArray postArray)
  {
    try {
      LinearLayout feed_container=findViewById(R.id.friendsListContainer);
      feed_container.removeAllViews();
      for (int i = 0; i <postArray.length() ; i++)
      {
        JSONArray row=postArray.getJSONArray(i);
        //username0 name1 photo2
        LinearLayout child= (LinearLayout) getLayoutInflater().inflate(R.layout.one_friend_layout,null);
//        LinearLayout.LayoutParams lp= new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
//        lp.setMargins(0,20,0,20);
//        child.setLayoutParams(lp);
        ((TextView)child.findViewById(R.id.friendName)).setText(row.getString(1));
        //handle more options
        child.findViewById(R.id.parent).setTag(row.getString(0));
        child.findViewById(R.id.parent).setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View view)
          {
            Log.d("#info","open:"+view.getTag().toString());
            Intent intent=new Intent(ShowFriendsToStartMessage.this,ChatWindow.class);
            intent.putExtra("recipient",view.getTag().toString());
            startActivity(intent);
          }
        });

        feed_container.addView(child);
      }

      //now load groups
      getGroupList();
    } catch (JSONException e) {
      e.printStackTrace();
    }
  }

  public void getGroupList()
  {
    try
    {

      StringRequest putRequest = new StringRequest(Method.POST, Utility.siteUrl+"/getGroupsList.php",
          new Response.Listener<String>()
          {
            @Override
            public void onResponse(String response) {
              // response
              try
              {
                Log.d("#info",response);
                JSONObject obj=new JSONObject(response);
                if (obj.getBoolean("success"))
                {
                  Log.d("#info",obj.getJSONArray("list").toString());
                  createGroupListLayout(obj.getJSONArray("list"));
                }
              } catch (Exception e)
              {
                e.printStackTrace();
              }
            }
          },
          new Response.ErrorListener()
          {
            @Override
            public void onErrorResponse(VolleyError error)
            {
              Toast.makeText(ShowFriendsToStartMessage.this,"Error while getting friend list: Error is:"+error.getMessage(),Toast.LENGTH_LONG);
            }
          }
      ) {

        @Override
        protected Map<String, String> getParams()
        {
          Map<String, String>  params = new HashMap<String, String>();
          params.put("username",TinyDB.getInstance().getString("username"));
          return params;
        }

      };

      RequestQueue requestQueue= Volley.newRequestQueue(this);
      requestQueue.add(putRequest);
      requestQueue.start();

    }catch (Exception e)
    {
      e.printStackTrace();

    }
  }

  public void createGroupListLayout(JSONArray postArray)
  {

    try {
      LinearLayout feed_container=findViewById(R.id.friendsListContainer);
      for (int i = 0; i <postArray.length() ; i++)
      {
        JSONArray row=postArray.getJSONArray(i);
        //groupid0 admin1 groupname2 groupstate3 photo4 time5
        LinearLayout child= (LinearLayout) getLayoutInflater().inflate(R.layout.one_friend_layout,null);
        ((TextView)child.findViewById(R.id.friendName)).setText(row.getString(2));

        child.findViewById(R.id.parent).setTag(row.toString());
        child.findViewById(R.id.parent).setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View view)
          {
            Log.d("#info","groupid:"+view.getTag().toString());
            Intent intent=new Intent(ShowFriendsToStartMessage.this,ChatWindowGroups.class);
            intent.putExtra("groupDataJson",view.getTag().toString());
            startActivity(intent);
          }
        });

        feed_container.addView(child);
      }
    } catch (JSONException e) {
      e.printStackTrace();
    }
  }

}
