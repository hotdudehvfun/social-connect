package com.hotdudehvfun.asocial;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.Request.Method;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.NetworkImageView;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;



// TODO: get friend list
public class ShowFriendsToStartMessage extends AppCompatActivity {

  TextView log;
  @Override
  protected void onCreate(Bundle savedInstanceState) {
    try {
      super.onCreate(savedInstanceState);
      setContentView(R.layout.activity_show_friends_to_start_message);


      log=findViewById(R.id.log);
      getRecentChatUsers();
    } catch (Exception e)
    {
      e.printStackTrace();
    }


  }



  public void getRecentChatUsers()
  {
    try
    {

      StringRequest putRequest = new StringRequest(Method.POST, Utility.siteUrl+"/getRecentChatUsers.php",
          new Response.Listener<String>()
          {
            @Override
            public void onResponse(String response) {
              // response
              try
              {
                Log.d("#info",response);
                JSONObject obj=new JSONObject(response);
                JSONArray sent=obj.getJSONArray("listSent");
                JSONArray received=obj.getJSONArray("listReceived");

                Set<String> uniqueRows=new HashSet<>();
                for (int i = 0; i < sent.length(); i++)
                {
//                  uniqueRows.add(new UserEntity(
//                      sent.getJSONObject(i).getString("username"),
//                      sent.getJSONObject(i).getString("name"),
//                      sent.getJSONObject(i).getString("photo")));
                  uniqueRows.add(sent.getJSONObject(i).toString());
                }
                for (int i = 0; i < received.length(); i++)
                {
//                  uniqueRows.add(new UserEntity(
//                      received.getJSONObject(i).getString("username"),
//                      received.getJSONObject(i).getString("name"),
//                      received.getJSONObject(i).getString("photo")));
                  uniqueRows.add(received.getJSONObject(i).toString());
                }

                createRecentChatUsersListLayout(uniqueRows);
              } catch (Exception e)
              {
                e.printStackTrace();
              }
            }
          },
          new Response.ErrorListener()
          {
            @Override
            public void onErrorResponse(VolleyError error)
            {
              Toast.makeText(ShowFriendsToStartMessage.this,"Error while getting friend list: Error is:"+error.getMessage(),Toast.LENGTH_LONG);
            }
          }
      ) {

        @Override
        protected Map<String, String> getParams()
        {
          Map<String, String>  params = new HashMap<String, String>();
          params.put("username",TinyDB.getInstance().getString("username"));
          return params;
        }

      };

      RequestQueue requestQueue= Volley.newRequestQueue(this);
      requestQueue.add(putRequest);
      requestQueue.start();

    }catch (Exception e)
    {
      e.printStackTrace();

    }
  }

  public void createRecentChatUsersListLayout(Set<String> recentChatUsers)
  {
    try {
      LinearLayout feed_container=findViewById(R.id.friendsListContainer);
      feed_container.removeAllViews();
      if (recentChatUsers.size()==0)
      {
        log.setText("You have no recent chats!");
      }else
      {
        //first clean received data
        for(String s:recentChatUsers)
        {
          JSONObject tempObj=new JSONObject(s);
          UserEntity userData=new UserEntity(tempObj.getString("username"),tempObj.getString("name"),tempObj.getString("photo"));
          LinearLayout child= (LinearLayout) getLayoutInflater().inflate(R.layout.one_friend_layout,null);

          ((TextView)child.findViewById(R.id.friendName)).setText(userData.name);
          Utility.getImage(getApplicationContext(),Utility.siteUrl+userData.photo,(NetworkImageView) child.findViewById(R.id.friendProfileIcon));

          //handle click on friend
          child.findViewById(R.id.parent).setTag(userData);
          child.findViewById(R.id.parent).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
              Intent intent=new Intent(ShowFriendsToStartMessage.this,ChatWindow.class);
              try {
                UserEntity temp= (UserEntity) view.getTag();
                intent.putExtra("person-username",temp.username);
                intent.putExtra("person-name",temp.name);
                intent.putExtra("person-photo",temp.photo);
                startActivity(intent);
              } catch (Exception e) {
                e.printStackTrace();
              }
            }
          });

          //handle accept and cancel request on sent and received
          //incoming
          //can be cancelled or accepted

          //hide accept button
          //show only if incoming requests
          LinearLayout actionContainer=child.findViewById(R.id.friend_request_action_container);
          actionContainer.setVisibility(View.GONE);
          feed_container.addView(child);
        }

      }
      getGroupList();

    } catch (Exception e) {
      e.printStackTrace();
    }
  }


  public void getFriendList()
  {
    try
    {

      StringRequest putRequest = new StringRequest(Method.POST, Utility.siteUrl+"/getFriendsList.php",
          new Response.Listener<String>()
          {
            @Override
            public void onResponse(String response) {
              // response
              try
              {
                Log.d("#info",response);
                JSONObject obj=new JSONObject(response);
                createFriendListLayout(obj.getJSONArray("friendList"));
              } catch (Exception e)
              {
                e.printStackTrace();
              }
            }
          },
          new Response.ErrorListener()
          {
            @Override
            public void onErrorResponse(VolleyError error)
            {
              Toast.makeText(ShowFriendsToStartMessage.this,"Error while getting friend list: Error is:"+error.getMessage(),Toast.LENGTH_LONG);
            }
          }
      ) {

        @Override
        protected Map<String, String> getParams()
        {
          Map<String, String>  params = new HashMap<String, String>();
          params.put("username",TinyDB.getInstance().getString("username"));
          return params;
        }

      };

      RequestQueue requestQueue= Volley.newRequestQueue(this);
      requestQueue.add(putRequest);
      requestQueue.start();

    }catch (Exception e)
    {
      e.printStackTrace();

    }
  }

  public void createFriendListLayout(JSONArray postArray)
  {
    try {
      LinearLayout feed_container=findViewById(R.id.friendsListContainer);
      feed_container.removeAllViews();
      if (postArray.length()==0)
      {
        log.setText("You have no friends!");
      }else
      {

        for (int i = 0; i <postArray.length() ; i++)
        {
          JSONObject row=postArray.getJSONObject(i);
          //username0 name1 photo2
          LinearLayout child= (LinearLayout) getLayoutInflater().inflate(R.layout.one_friend_layout,null);


          ((TextView)child.findViewById(R.id.friendName)).setText(row.getString("name"));
          Utility.getImage(getApplicationContext(),Utility.siteUrl+row.getString("photo"),(NetworkImageView) child.findViewById(R.id.friendProfileIcon));

          //handle click on friend
          child.findViewById(R.id.parent).setTag(row.toString());
          child.findViewById(R.id.parent).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
              Intent intent=new Intent(ShowFriendsToStartMessage.this,ChatWindow.class);
              try {
                JSONObject temp=new JSONObject(view.getTag().toString());
                intent.putExtra("person-username",temp.getString("username"));
                intent.putExtra("person-name",temp.getString("name"));
                intent.putExtra("person-photo",temp.getString("photo"));
                startActivity(intent);
              } catch (JSONException e) {
                e.printStackTrace();
              }
            }
          });

          //handle accept and cancel request on sent and received
          //incoming
          //can be cancelled or accepted

          //hide accept button
          //show only if incoming requests
          LinearLayout actionContainer=child.findViewById(R.id.friend_request_action_container);
          actionContainer.setVisibility(View.GONE);
          feed_container.addView(child);
        }

      }
      getGroupList();

    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public void getGroupList()
  {
    try
    {

      StringRequest putRequest = new StringRequest(Method.POST, Utility.siteUrl+"/getGroupsList.php",
          new Response.Listener<String>()
          {
            @Override
            public void onResponse(String response) {
              // response
              try
              {
                Log.d("#info",response);
                JSONObject obj=new JSONObject(response);
                if (obj.getBoolean("success"))
                {
                  if (obj.getInt("rowCount")>0)
                  {
                    createGroupListLayout(obj.getJSONArray("list"));
                  }
                }
              } catch (Exception e)
              {
                e.printStackTrace();
              }
            }
          },
          new Response.ErrorListener()
          {
            @Override
            public void onErrorResponse(VolleyError error)
            {
              Toast.makeText(ShowFriendsToStartMessage.this,"Error while getting friend list: Error is:"+error.getMessage(),Toast.LENGTH_LONG);
            }
          }
      ) {

        @Override
        protected Map<String, String> getParams()
        {
          Map<String, String>  params = new HashMap<String, String>();
          params.put("username",TinyDB.getInstance().getString("username"));
          return params;
        }

      };

      RequestQueue requestQueue= Volley.newRequestQueue(this);
      requestQueue.add(putRequest);
      requestQueue.start();

    }catch (Exception e)
    {
      e.printStackTrace();

    }
  }

  public void createGroupListLayout(JSONArray postArray)
  {

    try {
      LinearLayout feed_container=findViewById(R.id.friendsListContainer);
      for (int i = 0; i <postArray.length() ; i++)
      {
        JSONArray row=postArray.getJSONArray(i);
        //groupid0	username1	rights2	groupid3	admin4	groupname5	groupState6	photo7	time8
        LinearLayout child= (LinearLayout) getLayoutInflater().inflate(R.layout.one_friend_layout,null);
        LinearLayout actionContainer=child.findViewById(R.id.friend_request_action_container);
        actionContainer.setVisibility(View.GONE);

        ((TextView)child.findViewById(R.id.friendName)).setText(row.getString(5));

        Utility.getImage(getApplicationContext(),Utility.siteUrl+row.getString(7),
            (NetworkImageView) child.findViewById(R.id.friendProfileIcon));

        child.findViewById(R.id.parent).setTag(row.toString());
        child.findViewById(R.id.parent).setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View view)
          {
            Intent intent=new Intent(ShowFriendsToStartMessage.this,ChatWindowGroups.class);
            intent.putExtra("groupDataJson",view.getTag().toString());
            startActivity(intent);
          }
        });

        feed_container.addView(child);
      }
    } catch (JSONException e) {
      e.printStackTrace();
    }
  }

}
