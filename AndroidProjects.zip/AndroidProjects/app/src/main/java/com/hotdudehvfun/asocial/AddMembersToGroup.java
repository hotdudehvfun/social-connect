package com.hotdudehvfun.asocial;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.Request.Method;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.NetworkImageView;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class AddMembersToGroup extends AppCompatActivity {


  int groupId;
  TextView log;
  ArrayList<String> usernamesToAdd;
  @Override
  protected void onCreate(Bundle savedInstanceState) {

    try {
      super.onCreate(savedInstanceState);
      setContentView(R.layout.activity_add_members_to_group);

      log=findViewById(R.id.log);
      groupId=getIntent().getIntExtra("groupId",-1);
      if (groupId==-1)
      {
        Utility.sb(findViewById(R.id.parent),"Error while getting group information!");
      }else{
        getFriendsButNotMembers();
      }

    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public void getFriendsButNotMembers()
  {
    try
    {
      log.setText("Getting your friends who are not member of this group!");
      StringRequest putRequest = new StringRequest(Method.POST, Utility.siteUrl+"/getFriendsListButNotMember.php",
          new Response.Listener<String>()
          {
            @Override
            public void onResponse(String response) {
              // response
              try
              {
                Log.d("#info",response);
                JSONObject obj=new JSONObject(response);
                log.setText(obj.getString("message"));
                if (obj.getBoolean("success"))
                {
                  if (obj.getInt("rowCount")>0)
                  {
                    createListLayout(obj.getJSONArray("list"));
                  }
                }
              } catch (Exception e)
              {
                e.printStackTrace();
              }
            }
          },
          new Response.ErrorListener()
          {
            @Override
            public void onErrorResponse(VolleyError error)
            {
              Toast.makeText(AddMembersToGroup.this,"Error while getting friend list: Error is:"+error.getMessage(),Toast.LENGTH_LONG).show();
            }
          }
      ) {

        @Override
        protected Map<String, String> getParams()
        {
          Map<String, String>  params = new HashMap<String, String>();
          params.put("username",TinyDB.getInstance().getString("username"));
          params.put("groupid", String.valueOf(groupId));
          return params;
        }

      };

      RequestQueue requestQueue= Volley.newRequestQueue(this);
      requestQueue.add(putRequest);
      requestQueue.start();

    }catch (Exception e)
    {
      e.printStackTrace();

    }
  }

  public void createListLayout(JSONArray postArray)
  {
    try {
      LinearLayout feed_container=findViewById(R.id.listContainer);
      feed_container.removeAllViews();
      usernamesToAdd=new ArrayList<>();
      if (postArray.length()>0)
      {
        log.setText("Press back button when done adding!!!");
        for (int i = 0; i <postArray.length() ; i++)
        {
          JSONArray row=postArray.getJSONArray(i);
          //username0 name1 photo2
          final LinearLayout child= (LinearLayout) getLayoutInflater().inflate(R.layout.one_friend_layout,null);

          ((TextView)child.findViewById(R.id.friendName)).setText(row.getString(1));
          Utility.getImage(getApplicationContext(),Utility.siteUrl+row.getString(2),(NetworkImageView) child.findViewById(R.id.friendProfileIcon));


          child.findViewById(R.id.friend_request_action_container).setVisibility(View.VISIBLE);
          child.findViewById(R.id.friend_request_action_container).findViewById(R.id.cancel_action).setVisibility(View.GONE);
          child.findViewById(R.id.friend_request_action_container).findViewById(R.id.accept_action).setVisibility(View.VISIBLE);


          ((TextView)child.findViewById(R.id.friend_request_action_container).findViewById(R.id.accept_action)).setText("TAP TO ADD");
          child.setTag(row.getString(0));
          child.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
              boolean isRemoved=usernamesToAdd.remove(view.getTag().toString());
              Log.d("#removed","removed="+isRemoved);
              if (!isRemoved)
              {
                //isRemoved=false was not present add it now
                usernamesToAdd.add(view.getTag().toString());
                ((TextView)child.findViewById(R.id.friend_request_action_container).findViewById(R.id.accept_action)).setText("ADDED IN GROUP");
                ((TextView)child.findViewById(R.id.friend_request_action_container).findViewById(R.id.accept_action)).setBackground(getDrawable(R.drawable.chip_green));

              }
              if(isRemoved){
                //isRemoved=true means was present now removed
                ((TextView)child.findViewById(R.id.friend_request_action_container).findViewById(R.id.accept_action)).setText("TAP TO ADD");
                ((TextView)child.findViewById(R.id.friend_request_action_container).findViewById(R.id.accept_action)).setBackground(getDrawable(R.drawable.chip_accent));

              }
            }
          });

          feed_container.addView(child);
        }

      }

    } catch (Exception e) {
      e.printStackTrace();
    }
  }



  public void addUsernameListToGroup()
  {
    try
    {
      log.setText("Please wait while we add members to group!");
      StringRequest putRequest = new StringRequest(Method.POST, Utility.siteUrl+"/addMembersToGroup.php",
          new Response.Listener<String>()
          {
            @Override
            public void onResponse(String response) {
              // response
              try
              {
                Log.d("#info",response);
                JSONObject obj=new JSONObject(response);
                Toast.makeText(AddMembersToGroup.this,obj.getString("message"),Toast.LENGTH_LONG).show();
                finish();

              } catch (Exception e)
              {
                e.printStackTrace();
              }
            }
          },
          new Response.ErrorListener()
          {
            @Override
            public void onErrorResponse(VolleyError error)
            {
              Toast.makeText(AddMembersToGroup.this,"Error while getting friend list: Error is:"+error.getMessage(),Toast.LENGTH_LONG).show();
            }
          }
      ) {

        @Override
        protected Map<String, String> getParams()
        {
          Map<String, String>  params = new HashMap<String, String>();
          params.put("jsonList",new JSONArray(usernamesToAdd).toString());
          params.put("groupid", String.valueOf(groupId));
          return params;
        }

      };

      RequestQueue requestQueue= Volley.newRequestQueue(this);
      requestQueue.add(putRequest);
      requestQueue.start();

    }catch (Exception e)
    {
      e.printStackTrace();

    }
  }

  @Override
  public void onBackPressed()
  {
    if (usernamesToAdd.size()>0)
    {
      //add list to group
      addUsernameListToGroup();

    }else
      {
      finish();
    }
  }
}
